const vm=require('vm'),fs=require('fs'),assert=require('assert/strict');
const a=require('path').resolve(__dirname,'../app/src/main/assets')+'/';
function element(){return {style:{},childNodes:[],children:[],appendChild(c){this.childNodes.push(c);this.children.push(c);},setAttribute(){},getContext(){return {clearRect(){},fillRect(){},strokeRect(){},drawImage(){}}},toDataURL(){return 'data:image/png;base64,'},get offsetWidth(){return 100},get offsetHeight(){return 100}};}
const context={document:{documentElement:{tagName:'html'},createElement:element,getElementById:element},navigator:{userAgent:'Node'},CanvasRenderingContext2D:function(){},Image:function(){},setTimeout,console};context.window=context;
vm.createContext(context);vm.runInContext(fs.readFileSync(a+'vendor/qrcode.min.js','utf8'),context);
const decode=require(a+'vendor/jsQR.js');
const data=JSON.parse(fs.readFileSync(a+'database.json'));let count=0;
for(const tag of new Set(data.map(r=>r.equipment))){
 const text='SLM:EQUIPMENT:'+tag,code=new context.QRCode(element(),{text,width:128,height:128,correctLevel:context.QRCode.CorrectLevel.M}),m=code._oQRCode.modules,n=m.length,scale=4,size=(n+8)*scale,pixels=new Uint8ClampedArray(size*size*4).fill(255);
 for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(m[y][x])for(let dy=0;dy<scale;dy++)for(let dx=0;dx<scale;dx++){let i=(((y+4)*scale+dy)*size+(x+4)*scale+dx)*4;pixels[i]=pixels[i+1]=pixels[i+2]=0;}
 const result=decode(pixels,size,size);assert.equal(result?.data,text);count++;
}
console.log('PASS: offline QR encode/decode for all '+count+' equipment tags');
