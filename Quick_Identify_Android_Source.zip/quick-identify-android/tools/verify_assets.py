"""Run from project root: python3 tools/verify_assets.py"""
import collections, json, re, xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parents[1];assets=root/'app/src/main/assets'
rows=json.loads((assets/'database.json').read_text())
state=json.loads((assets/'data.js').read_text().removeprefix('window.QIE_INITIAL = ').strip().removesuffix(';'))
assert len(rows)==825
assert len({r['equipment'] for r in rows})==291
assert rows==state['lubricationDatabase']
assert len({r['id'] for r in rows})==825
assert collections.Counter(r['sourcePage'] for r in rows)=={1:77,2:80,3:80,4:88,5:66,6:89,7:79,8:82,9:81,10:87,11:16}
assert collections.Counter(r['type'] for r in rows)=={'GREASE':607,'OIL':214,'THERMAL FLUID':2,'GLYCERINE':2}
assert sum(any(r[k].startswith('#') for k in ['rateHr','consumptionMtH']) for r in rows)==56
points=[p for e in state['equipment'] for p in e['points']]
assert len(points)==825 and {p['sourceId'] for p in points}=={r['id'] for r in rows}
byid={r['id']:r for r in rows}
for e in state['equipment']:
 for p in e['points']:
  r=byid[p['sourceId']]
  assert r['equipment']==e['tag'] and r['name']==p['lubricant'] and r['capacity']==p['capacity'] and r['notes']==p['notes']
assert any(r['equipment']=='02-10CV007' and r['component']=='GEARBOX' and r['name']=='OMALA S2 GX 460' for r in rows)
assert any(r['equipment']=='03-10CP604' and r['capacity']=='130' and r['name']=='Roto Synthetic Fluid Xtend Duty' for r in rows)
html=(assets/'index.html').read_text()
assert not re.search(r'<script[^>]+src=["\']https?://',html)
for resource in re.findall(r'<(?:script|link)[^>]+(?:src|href)=["\']([^"\']+)',html):assert (assets/resource).is_file(),resource
for path in root.glob('app/src/main/**/*.xml'):ET.parse(path)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' not in manifest
java=(root/'app/src/main/java/com/wahyusn/quickidentify/MainActivity.java').read_text()
assert 'import android.print.PrintManager;' in java
assert max(p.stat().st_size for p in root.rglob('*') if p.is_file())<25*1024*1024
print('PASS: 825 rows; 291 equipment; 11 pages; full point linkage; source error retention; offline assets; XML; PrintManager import.')
