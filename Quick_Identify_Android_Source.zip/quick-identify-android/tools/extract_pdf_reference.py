from pathlib import Path
import pdfplumber,json,re,collections,bisect
keys=['area','equipment','description','component','modifier','type','brand','name','oilLifeTarget','topUpFactor','capacity','units','workingHrsYear','rateHr','consumptionMtH','notes']
bounds=[18,79.2,115.8,197.1,258,290.7,317.8,350.8,430.2,454.5,475.3,501.7,517.5,543.8,566.3,607.0,792]
import argparse
parser=argparse.ArgumentParser(description='Extract this Processing Plant PDF layout, preserving blank and error cells.')
parser.add_argument('pdf');parser.add_argument('output')
args=parser.parse_args()
rows=[]
with pdfplumber.open(args.pdf) as pdf:
 for pi,p in enumerate(pdf.pages):
  chunks=[];last=None
  for c in p.chars:
   if c['top']<62:continue
   if last is None or abs(c['top']-last['top'])>1 or c['x0']-last['x1']>1.7 or c['x0']-last['x1']<-.5:
    chunks.append({'x':c['x0'],'y':c['top'],'t':''})
   chunks[-1]['t']+=c['text'];last=c
  tags=[c for c in chunks if 79.2<=c['x']<80.2 and re.fullmatch(r'\d{2}-\d{2}-?[A-Z]+\d+',c['t'].strip())]
  shaded=[r for r in p.rects if r['width']>740 and r['height']>2 and r['top']>62]
  bands=[]
  for tag in tags:
   shade=next((r for r in shaded if r['top']<=tag['y']+2<r['bottom']),None)
   if shade:lo,hi=shade['top'],shade['bottom']
   else:
    lo=max([r['bottom'] for r in shaded if r['bottom']<tag['y']+2]+[63.12]);hi=min([r['top'] for r in shaded if r['top']>tag['y']+2]+[580])
   row={k:'' for k in keys}
   for ch in chunks:
    if lo<=ch['y']+2<hi:
     k=keys[min(15,max(0,bisect.bisect_right(bounds,ch['x'])-1))]
     row[k]+=' '+ch['t']
   row={k:re.sub(r'\s+',' ',v).strip() for k,v in row.items()}
   row.update(id=f'ldb{len(rows)+1:04d}',sourcePage=pi+1)
   rows.append(row)
  print(pi+1,len(tags))
for r in rows:
 if not r['type'] and r['modifier'].endswith('GREASE'):
  r['modifier']=r['modifier'][:-6].strip();r['type']='GREASE'
 r['qualityFlags']=[f'{k}: nilai sumber {r[k]}' for k in ['rateHr','consumptionMtH'] if r[k].startswith('#')]
 for k in ['name','capacity','oilLifeTarget']:
  if not r[k] or r[k]=='-':r['qualityFlags'].append(k+': belum tersedia pada PDF')
Path(args.output).write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('Rows:',len(rows),'Equipment:',len({r['equipment'] for r in rows}))
