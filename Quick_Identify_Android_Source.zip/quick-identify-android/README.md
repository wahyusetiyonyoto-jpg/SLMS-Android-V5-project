# Quick Identify Equipment — Android offline v6

Proyek mandiri dari HTML dan PDF pengguna. Gunakan source ZIP + workflow yang disertakan untuk upload manual ke GitHub.

- JDK 17 / Gradle 8.11.1 / AGP 8.9.2 / SDK 35.
- Jalankan `gradle :app:assembleDebug :app:lintDebug`.
- `python3 tools/verify_assets.py` memeriksa database dan aset.
- `node tools/test-qr.cjs` memeriksa QR seluruh equipment.
- `tools/ui-test.cjs` memakai Playwright 1.55.0 dan server aset port 8765.
- `tools/extract_pdf_reference.py INPUT.pdf OUTPUT.json` memakai pdfplumber dan khusus tata letak PDF sumber ini; periksa hasil jika format PDF berubah.
- `testing.keystore` adalah kunci publik khusus testing, password/alias standar Android, jangan digunakan untuk rilis produksi.
- Tidak ada dependency runtime jaringan. Pustaka QR tersimpan beserta lisensi MIT.
- Android memakai AtomicFile privat untuk data teknis; database referensi berasal dari aset versi aplikasi.
- Source ID testing sengaja berbeda dari APK lama yang identitasnya belum diketahui.

Kompilasi dan uji UI belum dijalankan pada sesi pembuatan; workflow menyediakan gate tersebut. Pengujian perangkat masih wajib.
