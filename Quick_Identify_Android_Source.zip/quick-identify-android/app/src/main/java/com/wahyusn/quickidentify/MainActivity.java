package com.wahyusn.quickidentify;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.AtomicFile;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Bundled assets only. No INTERNET permission, remote navigation or external WebView content. */
public class MainActivity extends Activity {
    private static final String HOST="appassets.androidplatform.net";
    private static final String START="https://"+HOST+"/assets/index.html";
    private static final int PICK=41, SAVE=42, IMPORT=43, CAMERA=44;
    private static final int LIMIT=8*1024*1024;
    private WebView web, printWeb;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest cameraRequest;
    private byte[] pendingExport;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private AtomicFile stateFile;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        stateFile=new AtomicFile(new File(getFilesDir(),"equipment-state.json"));
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(0xff0b2d5c);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setGeolocationEnabled(false);
        s.setMediaPlaybackRequiresUserGesture(true);s.setSupportMultipleWindows(false);
        web.setWebViewClient(new LocalClient());
        web.addJavascriptInterface(new OfflineBridge(),"QIEAndroid");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onJsAlert(WebView v,String url,String msg,JsResult result){
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("OK",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onJsConfirm(WebView v,String url,String msg,JsResult result){
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("Lanjut",(d,w)->result.confirm()).setNegativeButton("Batal",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
                try{startActivityForResult(intent,PICK);}catch(ActivityNotFoundException e){fileCallback.onReceiveValue(null);fileCallback=null;message("Pemilih file tidak tersedia.");}return true;
            }
        });
        web.loadUrl(START);
    }
    private boolean local(Uri u){return "https".equals(u.getScheme()) && HOST.equals(u.getHost()) && u.getPath()!=null && u.getPath().startsWith("/assets/");}
    private class LocalClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !local(r.getUrl());}
        @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
            Uri u=r.getUrl();
            if(local(u)){
                String path=u.getPath().substring(8);
                if(!path.contains("..") && !path.contains("\\"))try{
                    String mime=path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".html")?"text/html":path.endsWith(".json")?"application/json":path.endsWith(".png")?"image/png":path.endsWith(".jpg")?"image/jpeg":"application/octet-stream";
                    return new WebResourceResponse(mime,"UTF-8",getAssets().open(path));
                }catch(Exception ignored){}
            }
            return new WebResourceResponse("text/plain","UTF-8",404,"Unavailable",java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
        }
    }
    public class OfflineBridge {
        @JavascriptInterface public String readState(){synchronized(stateFile){try{return new String(stateFile.readFully(),StandardCharsets.UTF_8);}catch(Exception e){return "null";}}}
        @JavascriptInterface public boolean writeState(String data){
            if(data==null||data.length()>LIMIT)return false;
            synchronized(stateFile){FileOutputStream stream=null;try{new JSONObject(data);stream=stateFile.startWrite();stream.write(data.getBytes(StandardCharsets.UTF_8));stateFile.finishWrite(stream);return true;}catch(Exception e){stateFile.failWrite(stream);return false;}}
        }
        @JavascriptInterface public void saveFile(String name,String mime,String base64){
            if(base64==null||base64.length()>LIMIT*2){message("File terlalu besar.");return;}
            final byte[] bytes;try{bytes=Base64.decode(base64,Base64.DEFAULT);}catch(Exception e){message("File tidak valid.");return;}
            if(bytes.length>LIMIT){message("Maksimum file 8 MB.");return;}
            runOnUiThread(()->{
                if(pendingExport!=null){message("Selesaikan penyimpanan sebelumnya.");return;}
                pendingExport=bytes;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime==null?"application/octet-stream":mime).putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^a-zA-Z0-9._-]","_"));
                try{startActivityForResult(intent,SAVE);}catch(ActivityNotFoundException e){pendingExport=null;message("Pemilih penyimpanan tidak tersedia.");}
            });
        }
        @JavascriptInterface public void importBackup(){runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),IMPORT);}catch(ActivityNotFoundException e){message("Pemilih file tidak tersedia.");}});}
        @JavascriptInterface public void printLabel(String image,String tag,String name,String area){
            if(image==null||!image.startsWith("data:image/png;base64,")||image.length()>LIMIT)return;
            runOnUiThread(()->{
                if(printWeb!=null)printWeb.destroy();printWeb=new WebView(MainActivity.this);
                printWeb.getSettings().setJavaScriptEnabled(false);printWeb.getSettings().setAllowFileAccess(false);printWeb.getSettings().setAllowContentAccess(false);
                printWeb.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){
                    PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
                    if(manager!=null)manager.print("QR "+tag,view.createPrintDocumentAdapter("QR "+tag),new PrintAttributes.Builder().build());
                }});
                String html="<!doctype html><meta charset='utf-8'><meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; img-src data:; style-src 'unsafe-inline'\"><style>body{font:16px sans-serif;text-align:center;padding:24px}img{width:230px;height:230px}</style><h2>Quick Identify Equipment</h2><img src='"+image+"'><h1>"+escape(tag)+"</h1><p>"+escape(name)+"</p><p>"+escape(area)+"</p><small>Scan melalui aplikasi Quick Identify Equipment</small>";
                printWeb.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
            });
        }
    }
    private static String escape(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    private void message(String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show());}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK){if(fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);fileCallback=null;}return;}
        if(request==SAVE){final byte[] bytes=pendingExport;pendingExport=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null){Uri uri=data.getData();io.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception();out.write(bytes);message("File berhasil disimpan.");}catch(Exception e){message("Gagal menyimpan file.");}});}return;}
        if(request==IMPORT && result==RESULT_OK && data!=null && data.getData()!=null){Uri uri=data.getData();io.execute(()->{
            try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new Exception();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>LIMIT)throw new Exception();out.write(buffer,0,n);}
                String text=out.toString("UTF-8");runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.QIERestore("+JSONObject.quote(text)+")",null);});
            }catch(Exception e){message("Backup tidak dapat dibaca atau melebihi 8 MB.");}
        });}
    }
    @Override public void onBackPressed(){web.evaluateJavascript("window.QIEBack ? window.QIEBack() : false",handled->{if(!"true".equals(handled))new AlertDialog.Builder(this).setMessage("Tutup Quick Identify Equipment?").setPositiveButton("Tutup",(d,w)->finish()).setNegativeButton("Batal",null).show();});}
    @Override protected void onPause(){if(web!=null){web.evaluateJavascript("document.querySelectorAll('video').forEach(v=>{if(v.srcObject)v.srcObject.getTracks().forEach(t=>t.stop())})",null);web.onPause();}super.onPause();}
    @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
    @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.removeJavascriptInterface("QIEAndroid");web.destroy();web=null;}if(printWeb!=null)printWeb.destroy();io.shutdown();super.onDestroy();}
}
