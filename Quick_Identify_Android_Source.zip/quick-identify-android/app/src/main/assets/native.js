'use strict';
window.QIESaveFile = async (name,mime,text) => {
  const blob=new Blob([text],{type:mime});
  if(window.QIEAndroid){const r=new FileReader();r.onload=()=>QIEAndroid.saveFile(name,mime,String(r.result).split(',')[1]);r.readAsDataURL(blob);}
  else {const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
};
document.addEventListener('click',async event=>{
 const a=event.target.closest('a[download]');if(!a||!window.QIEAndroid)return;
 event.preventDefault();
 try {const blob=await (await fetch(a.href)).blob(),reader=new FileReader();reader.onload=()=>QIEAndroid.saveFile(a.download,blob.type||'application/octet-stream',String(reader.result).split(',')[1]);reader.readAsDataURL(blob);}catch(_){alert('File belum dapat disimpan.');}
},true);
