
  (() => {
    'use strict';

    const initialState = window.QIE_INITIAL;

    const storageKey = 'qie_offline_user_v1';
    let state;
    try { state = JSON.parse(window.QIEAndroid ? QIEAndroid.readState() : localStorage.getItem(storageKey)) || JSON.parse(JSON.stringify(initialState)); }
    catch (_) { state = JSON.parse(JSON.stringify(initialState)); }

    // Refresh the bundled reference while retaining operator-added assets and identity details.
    const savedEquipment = Array.isArray(state.equipment) ? state.equipment : [];
    const byTag = new Map(savedEquipment.map(e => [String(e.tag), e]));
    const identityKeys = ['serialNumber','brandModel','manufactureYear','powerSource','operationalStatus','criticality'];
    state.equipment = initialState.equipment.map(ref => {
      const e = JSON.parse(JSON.stringify(ref)), saved = byTag.get(ref.tag);
      if (saved) identityKeys.forEach(k => { if (saved[k] !== undefined) e[k] = saved[k]; });
      return e;
    });
    const referenceTags = new Set(initialState.equipment.map(e => e.tag));
    state.equipment.push(...savedEquipment.filter(e => e && e.id && e.tag && !referenceTags.has(e.tag)));
    state.lubricationDatabase = initialState.lubricationDatabase;
    state.lubricants = []; state.history = []; state.routeStarted = false;
    state.databaseVersion = initialState.databaseVersion;
    // Lengkapi data lama yang tersimpan di browser dengan field identitas equipment terbaru.
    state.equipment = Array.isArray(state.equipment) ? state.equipment.map((item, index) => ({
      ...item,
      unitNumber: item.unitNumber || item.tag || `UNIT-${String(index + 1).padStart(3, '0')}`,
      manufactureYear: item.manufactureYear || '-',
      powerSource: item.powerSource || '-',
      operationalStatus: item.operationalStatus || 'Operasional',
      area: item.area || item.location || '-',
      oilCapacity: item.oilCapacity || '',
      greaseCapacity: item.greaseCapacity || '',
      points: Array.isArray(item.points) ? item.points.map(p => ({...p, evidence: {...(p.evidence || {}), before:p.evidence?.before || '', after:p.evidence?.after || ''}})) : []
    })) : structuredClone(initialState.equipment);

    state.equipmentByUnit = new Map(state.equipment.map(e => [String(e.unitNumber), e]));

    function save() {
      resetEquipmentSearchCache();
      state.equipmentByUnit = new Map(state.equipment.map(e => [String(e.unitNumber), e]));
      try { const payload = JSON.stringify(state); if(window.QIEAndroid) { if(!QIEAndroid.writeState(payload)) throw new Error('Save failed'); } else localStorage.setItem(storageKey,payload); return true; }
      catch (err) { toast('Penyimpanan browser penuh. Hapus foto lama atau gunakan foto berukuran lebih kecil.'); return false; }
    }
    const $ = (s, root=document) => root.querySelector(s);
    const $$ = (s, root=document) => [...root.querySelectorAll(s)];
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));


    /* ---------- Lightweight bilingual UI (Bahasa Indonesia / English) ----------
       Design goals:
       - zero translation libraries / zero extra network requests
       - keep canonical application data unchanged
       - translate only UI text and accessibility attributes
       - no MutationObserver, so no continuous background work
    */
    const languageStorageKey = 'slm_ui_language_v1';
    let currentLanguage = 'id';
    try { currentLanguage = localStorage.getItem(languageStorageKey) === 'en' ? 'en' : 'id'; } catch (_) {}

    const languageEntries = [
      ['Smart Lubrication','Smart Lubrication','Smart Lubrication'],
      ['Masuk menggunakan akun pengguna untuk membuka aplikasi.','Masuk menggunakan akun pengguna untuk membuka aplikasi.','Sign in with your user account to open the application.'],
      ['Username','Username','Username'], ['Password','Password','Password'],
      ['Lihat','Lihat','Show'], ['Sembunyi','Sembunyi','Hide'], ['Ingat saya','Ingat saya','Remember me'],
      ['Masuk ke Aplikasi','Masuk ke Aplikasi','Sign In'], ['Akun awal:','Akun awal:','Default account:'],
      ['| Password:','| Password:','| Password:'], ['Dashboard','Dashboard','Dashboard'],
      ['Equipment','Equipment','Equipment'], ['Lubrication Database','Database Pelumasan','Lubrication Database'],
      ['Lubrication Points','Lubrication Points','Lubrication Points'], ['Grease & Oil Stock','Stok Grease & Oil','Grease & Oil Stock'],
      ['History','Riwayat','History'], ['Profil Pengguna','Profil Pengguna','User Profile'],
      ['⇥ Keluar Akun','⇥ Keluar Akun','⇥ Sign Out'], ['Keluar Akun','Keluar Akun','Sign Out'],
      ['Pastikan setiap titik grease dan oli terjadwal, terdokumentasi, dan tidak ada yang terlewat.','Pastikan setiap titik grease dan oli terjadwal, terdokumentasi, dan tidak ada yang terlewat.','Make sure every grease and oil point is scheduled, documented, and never missed.'],
      ['Install App','Instal Aplikasi','Install App'], ['Equipment Identification','Kontrol Pelumasan Digital','Equipment Identification'],
      ['Pelumasan tepat waktu, tepat produk, dan tepat titik.','Pelumasan tepat waktu, tepat produk, dan tepat titik.','Right time, right lubricant, right point.'],
      ['Monitor equipment, lubricant standard, lubrication points, serta completion checklist dalam satu aplikasi.','Pantau equipment, standar lubricant, lubrication points, serta checklist penyelesaian dalam satu aplikasi.','Monitor equipment, lubricant standards, lubrication points, and completion checklists in one application.'],
      ['Grease Points','Grease Points','Grease Points'], ['semua terbuka','semua terbuka','all open'],
      ['Total Equipment','Total Equipment','Total Equipment'], ['asset terdaftar','asset terdaftar','registered assets'],
      ['Lubrication Points','Lubrication Points','Lubrication Points'], ['titik aktif','titik aktif','active points'],
      ['Due Today','Jatuh Tempo Hari Ini','Due Today'], ['harus dikerjakan','harus dikerjakan','must be completed'],
      ['Overdue','Terlambat','Overdue'], ['perlu prioritas','perlu prioritas','needs priority'],
      ['Dashboard Detail','Detail Dashboard','Dashboard Detail'], ['Data Dashboard','Data Dashboard','Dashboard Data'],
      ['Daftar data berdasarkan indikator yang dipilih dari dashboard.','Daftar data berdasarkan indikator yang dipilih dari dashboard.','Data list based on the indicator selected from the dashboard.'],
      ['Total data','Total data','Total data'], ['Data mengikuti kondisi terbaru pada aplikasi.','Data mengikuti kondisi terbaru pada aplikasi.','Data reflects the latest state in the application.'],
      ['Cari equipment, area, titik pelumasan, atau lubricant...','Cari equipment, area, titik pelumasan, atau lubricant...','Search equipment, area, lubrication point, or lubricant...'],
      ['Data Total Equipment','Data Total Equipment','Total Equipment Data'], ['Daftar seluruh equipment yang terdaftar di Smart Lubrication Management.','Daftar seluruh equipment yang terdaftar di Smart Lubrication Management.','List of all equipment registered in Smart Lubrication Management.'],
      ['Data Titik Pelumasan','Data Titik Pelumasan','Lubrication Point Data'], ['Daftar seluruh lubrication point aktif beserta equipment, lubricant, interval, quantity, dan statusnya.','Daftar seluruh lubrication point aktif beserta equipment, lubricant, interval, quantity, dan statusnya.','List of all active lubrication points with equipment, lubricant, interval, quantity, and status.'],
      ['Data Jatuh Tempo Hari Ini','Data Jatuh Tempo Hari Ini','Due Today Data'], ['Equipment yang berstatus jatuh tempo dan harus dikerjakan hari ini.','Equipment yang berstatus jatuh tempo dan harus dikerjakan hari ini.','Equipment currently marked due and requiring work today.'],
      ['Data Terlambat','Data Terlambat','Overdue Data'], ['Equipment yang melewati jadwal pelumasan dan memerlukan prioritas.','Equipment yang melewati jadwal pelumasan dan memerlukan prioritas.','Equipment past its lubrication schedule and requiring priority.'],
      ['Buka Equipment','Buka Equipment','Open Equipment'], ['Nomor Unit','Nomor Unit','Unit Number'], ['Titik Pelumasan','Titik Pelumasan','Lubrication Point'], ['Interval','Interval','Interval'], ['Status','Status','Status'], ['Aksi','Aksi','Action'],
      ['asset terdaftar · klik untuk detail','asset terdaftar · klik untuk detail','registered assets · click for details'], ['titik aktif · klik untuk detail','titik aktif · klik untuk detail','active points · click for details'], ['harus dikerjakan · klik untuk detail','harus dikerjakan · klik untuk detail','must be completed · click for details'], ['perlu prioritas · klik untuk detail','perlu prioritas · klik untuk detail','needs priority · click for details'],
      ['Lubrication Points','Lubrication Points','Lubrication Points'], ['Semua greasing point dapat dipilih tanpa urutan wajib.','Semua greasing point dapat dipilih tanpa urutan wajib.','All greasing points can be selected without a mandatory sequence.'],
      ['Buka Points','Buka Points','Open Points'], ['Compliance','Kepatuhan','Compliance'],
      ['Penyelesaian pelumasan bulan berjalan.','Penyelesaian pelumasan bulan berjalan.','Lubrication completion for the current month.'],
      ['selesai','selesai','completed'], ['tertunda','tertunda','pending'], ['overdue','terlambat','overdue'],
      ['Equipment Kritis','Equipment Kritis','Critical Equipment'], ['Prioritas berdasarkan status pelumasan.','Prioritas berdasarkan status pelumasan.','Priority based on lubrication status.'],
      ['Quick Actions','Aksi Cepat','Quick Actions'], ['Akses cepat untuk aktivitas lapangan.','Akses cepat untuk aktivitas lapangan.','Quick access for field activities.'],
      ['☰ Lubrication Points','☰ Lubrication Points','☰ Lubrication Points'], ['＋ Tambah Equipment','＋ Tambah Equipment','＋ Add Equipment'],
      ['▣ Identifikasi Equipment','▣ Identifikasi Equipment','▣ Identify Equipment'], ['Identifikasi Equipment','Identifikasi Equipment','Identify Equipment'],
      ['◉ Lihat Lubricant','◉ Lihat Lubricant','◉ View Lubricants'], ['Asset Register','Register Asset','Asset Register'],
      ['Equipment & Lubrication Point','Equipment & Titik Pelumasan','Equipment & Lubrication Points'],
      ['Identitas teknis equipment, oil/grease specification & capacity, serta detail quantity setiap lubrication point.','Identitas teknis equipment, spesifikasi & kapasitas oil/grease, serta detail quantity setiap titik pelumasan.','Equipment technical identity, oil/grease specification and capacity, plus quantity details for each lubrication point.'],
      ['← Kembali','← Kembali','← Back'], ['Semua Area','Semua Area','All Areas'],
      ['Normal','Normal','Normal'], ['Due','Jatuh Tempo','Due'], ['Source Database 2026','Sumber Database 2026','Source Database 2026'],
      ['Lubrication Database Processing Plant','Database Pelumasan Processing Plant','Processing Plant Lubrication Database'],
      ['Database lubricant dari tabel Processing Plant 2026, diurutkan berdasarkan Equipment No. Seluruh field sumber ditampilkan di sini.','Database lubricant dari tabel Processing Plant 2026, diurutkan berdasarkan Equipment No. Seluruh field sumber ditampilkan di sini.','Lubricant database from the 2026 Processing Plant table, sorted by Equipment No. All source fields are shown here.'],
      ['⬇ Export Database CSV','⬇ Export Database CSV','⬇ Export Database CSV'], ['Total Lubrication Records','Total Record Pelumasan','Total Lubrication Records'],
      ['Grease Records','Record Grease','Grease Records'], ['Oil Records','Record Oil','Oil Records'], ['Semua Type','Semua Tipe','All Types'],
      ['25 / halaman','25 / halaman','25 / page'], ['50 / halaman','50 / halaman','50 / page'], ['100 / halaman','100 / halaman','100 / page'],
      ['Description','Deskripsi','Description'], ['Component','Komponen','Component'], ['Type','Tipe','Type'], ['Brand','Merek','Brand'],
      ['Lubricant Name','Nama Lubricant','Lubricant Name'], ['Capacity','Kapasitas','Capacity'], ['Units','Satuan','Units'], ['Notes','Catatan','Notes'],
      ['Field Lubrication','Field Lubrication','Field Lubrication'], ['Greasing Points','Greasing Points','Greasing Points'],
      ['Semua titik greasing dari seluruh equipment terbuka dan dapat dikerjakan dalam urutan apa pun sesuai kebutuhan lapangan.','Semua titik greasing dari seluruh equipment terbuka dan dapat dikerjakan dalam urutan apa pun sesuai kebutuhan lapangan.','All greasing points from all equipment are open and can be completed in any order based on field needs.'],
      ['Field Lubrication','Field Lubrication','Field Lubrication'], ['Greasing Points','Greasing Points','Greasing Points'],
      ['Semua titik greasing dari seluruh equipment terbuka dan dapat dikerjakan dalam urutan apa pun sesuai kebutuhan lapangan.','Semua titik greasing dari seluruh equipment terbuka dan dapat dikerjakan dalam urutan apa pun sesuai kebutuhan lapangan.','All greasing points from all equipment are open and can be completed in any order based on field needs.'],
      ['Urutan kerja bebas','Urutan kerja bebas','Free work order'], ['Semua lubrication point langsung terbuka. Teknisi dapat memilih point mana pun terlebih dahulu; tidak ada step terkunci dan tidak ada kewajiban mengikuti urutan tertentu.','Semua lubrication point langsung terbuka. Teknisi dapat memilih point mana pun terlebih dahulu; tidak ada step terkunci dan tidak ada kewajiban mengikuti urutan tertentu.','All lubrication points are immediately available. The technician can choose any point first; no steps are locked and no sequence is mandatory.'],
      ['Bebas dipilih','Bebas dipilih','Free selection'], ['📋 Open Point','📋 Buka Point','📋 Open Point'],
      ['Cari equipment, area, point, atau grease...','Cari equipment, area, point, atau grease...','Search equipment, area, point, or grease...'],
      ['Lubricant Master','Master Lubricant','Lubricant Master'],
      ['Data Grease & Oil Stock','Data Stok Grease & Oil','Grease & Oil Stock Data'],
      ['Standar produk, viscosity, application, dan stock minimum.','Standar produk, viscosity, application, dan stock minimum.','Product standard, viscosity, application, and minimum stock.'],
      ['＋ Tambah Lubricant','＋ Tambah Lubricant','＋ Add Lubricant'], ['🔎 Cari Stock','🔎 Cari Stock','🔎 Search Stock'], ['Reset','Reset','Reset'],
      ['Ketik huruf untuk mendapatkan sugesti pencarian secara langsung.','Ketik huruf untuk mendapatkan sugesti pencarian secara langsung.','Type letters to get instant search suggestions.'],
      ['Audit Trail','Jejak Audit','Audit Trail'], ['History Lubrication','Riwayat Pelumasan','Lubrication History'],
      ['Catatan pekerjaan, teknisi, quantity, dan hasil inspeksi.','Catatan pekerjaan, teknisi, quantity, dan hasil inspeksi.','Work records, technicians, quantities, and inspection results.'],
      ['Export CSV','Export CSV','Export CSV'], ['🔎 Cari History','🔎 Cari Riwayat','🔎 Search History'],
      ['Ketik huruf untuk memfilter history dan mendapatkan sugesti secara langsung.','Ketik huruf untuk memfilter riwayat dan mendapatkan sugesti secara langsung.','Type letters to filter history and get instant suggestions.'],
      ['Tanggal','Tanggal','Date'], ['Titik','Titik','Point'], ['Lubricant','Lubricant','Lubricant'], ['Qty','Qty','Qty'], ['Status','Status','Status'],
      ['Bukti Foto','Bukti Foto','Photo Evidence'], ['Aksi','Aksi','Actions'], ['User Account','Akun Pengguna','User Account'],
      ['Lihat dan perbarui identitas pengguna serta keamanan akun aplikasi.','Lihat dan perbarui identitas pengguna serta keamanan akun aplikasi.','View and update user identity and application account security.'],
      ['Akun Aktif','Akun Aktif','Active Account'], ['No. ID','No. ID','ID No.'], ['Area Kerja','Area Kerja','Work Area'],
      ['Informasi Pengguna','Informasi Pengguna','User Information'], ['Perubahan disimpan pada perangkat ini.','Perubahan disimpan pada perangkat ini.','Changes are saved on this device.'],
      ['Nama Lengkap','Nama Lengkap','Full Name'], ['Jabatan','Jabatan','Position'], ['Nomor Telepon','Nomor Telepon','Phone Number'],
      ['Ubah Password','Ubah Password','Change Password'], ['Password Saat Ini','Password Saat Ini','Current Password'],
      ['Password Baru','Password Baru','New Password'], ['Konfirmasi Password Baru','Konfirmasi Password Baru','Confirm New Password'],
      ['Login ini bekerja secara lokal di dalam file HTML. Untuk sistem perusahaan multi-pengguna, diperlukan server dan database autentikasi.','Login ini bekerja secara lokal di dalam file HTML. Untuk sistem perusahaan multi-pengguna, diperlukan server dan database autentikasi.','This login works locally inside the HTML file. A multi-user corporate system requires a server and authentication database.'],
      ['Batalkan Perubahan','Batalkan Perubahan','Cancel Changes'], ['Simpan Profil','Simpan Profil','Save Profile'], ['Profil','Profil','Profile'],
      ['Tambah Equipment','Tambah Equipment','Add Equipment'], ['Input asset dan standar pelumas utamanya.','Input asset dan standar pelumas utamanya.','Enter the asset and its main lubricant standards.'],
      ['Equipment Tag / Kode Asset','Equipment Tag / Kode Asset','Equipment Tag / Asset Code'], ['Nomor Unit','Nomor Unit','Unit Number'],
      ['Nama dan Jenis Alat','Nama dan Jenis Alat','Equipment Name and Type'],
      ['Tahun Pembuatan','Tahun Pembuatan','Manufacture Year'], ['Sumber Daya','Sumber Daya','Power Source'], ['Status Operasional','Status Operasional','Operational Status'],
      ['Operasional','Operasional','Operational'], ['Standby','Siaga','Standby'], ['Maintenance','Perawatan','Maintenance'], ['Breakdown','Rusak','Breakdown'], ['Out of Service','Tidak Beroperasi','Out of Service'],
      ['Lokasi','Lokasi','Location'], ['Criticality','Kritikalitas','Criticality'], ['High','Tinggi','High'], ['Medium','Sedang','Medium'], ['Low','Rendah','Low'],
      ['Status Jadwal Pelumasan','Status Jadwal Pelumasan','Lubrication Schedule Status'],
['Oil Type / Specification','Tipe / Spesifikasi Oil','Oil Type / Specification'],
      ['Oil Type','Tipe Oil','Oil Type'], ['Oil Capacity','Kapasitas Oil','Oil Capacity'], ['Grease Type / Specification','Tipe / Spesifikasi Grease','Grease Type / Specification'],
      ['Grease Type','Tipe Grease','Grease Type'], ['Total Grease Capacity / Service','Total Kapasitas Grease / Service','Total Grease Capacity / Service'],
      ['Kapasitas grease manual','Kapasitas grease manual','Kapasitas grease manual'], ['Greasing Point & Quantity per Point','Titik Greasing & Quantity per Titik','Greasing Points & Quantity per Point'],
      ['Lubrication Engineering Data','Data Engineering Pelumasan','Lubrication Engineering Data'],
      ['Jumlah greasing point dihitung otomatis dari daftar di atas. Quantity per point akan digunakan sebagai reference quantity pada Lubrication Points.','Jumlah greasing point dihitung otomatis dari daftar di atas. Quantity per point akan digunakan sebagai reference quantity pada Lubrication Points.','The number of greasing points is calculated automatically from the list above. Quantity per point is used as the reference quantity in Lubrication Points.'],
      ['Calculated Greasing Point','Greasing Point Terhitung','Calculated Greasing Points'], ['Cancel','Batal','Cancel'], ['Save Equipment Data','Simpan Data Equipment','Save Equipment Data'],
      ['Edit Equipment','Edit Equipment','Edit Equipment'], ['Save Technical Changes','Simpan Perubahan Teknis','Save Technical Changes'],
      ['Tambah Lubricant','Tambah Lubricant','Add Lubricant'], ['Master grease atau oil baru.','Master grease atau oil baru.','Create a new grease or oil master record.'],
      ['Nama Produk','Nama Produk','Product Name'], ['Tipe','Tipe','Type'], ['Grade / Viscosity','Grade / Viscosity','Grade / Viscosity'], ['Application','Aplikasi','Application'],
      ['Stock','Stok','Stock'], ['Minimum Stock','Stok Minimum','Minimum Stock'], ['Batal','Batal','Cancel'], ['Simpan','Simpan','Save'],
      ['Edit Lubricant','Edit Lubricant','Edit Lubricant'], ['Simpan Perubahan','Simpan Perubahan','Save Changes'],
      ['Greasing Point Execution','Eksekusi Titik Greasing','Greasing Point Execution'], ['Technical Reference','Referensi Teknis','Technical Reference'],
      ['Execution Status','Status Eksekusi','Execution Status'], ['Completed / Selesai','Selesai','Completed'], ['Unable to Execute / Tidak dapat dikerjakan','Tidak dapat dikerjakan','Unable to Execute'],
      ['Applied Lubricant Quantity','Quantity Lubricant Terpakai','Applied Lubricant Quantity'], ['Condition Finding / Inspection Note','Temuan Kondisi / Catatan Inspeksi','Condition Finding / Inspection Note'],
      ['Reason / Execution Constraint','Alasan / Kendala Eksekusi','Reason / Execution Constraint'], ['Photo Evidence / Bukti Pekerjaan','Bukti Foto / Bukti Pekerjaan','Photo Evidence / Work Evidence'],
      ['Ambil foto langsung dari kamera atau pilih dari galeri. Untuk status Completed, BEFORE dan AFTER wajib tersedia.','Ambil foto langsung dari kamera atau pilih dari galeri. Untuk status Selesai, BEFORE dan AFTER wajib tersedia.','Take a photo directly with the camera or choose one from the gallery. For Completed status, BEFORE and AFTER are required.'],
['Preview:','Preview:','Preview:'],
      ['foto akan langsung tampil di kotak ini. Tap foto untuk memperbesar.','foto akan langsung tampil di kotak ini. Tap foto untuk memperbesar.','the photo will appear here immediately. Tap it to enlarge.'],
            ['Remove Temperature Photo','Hapus Foto Temperatur','Remove Temperature Photo'], ['BEFORE — Actual Condition','BEFORE — Kondisi Aktual','BEFORE — Actual Condition'],
      ['Kondisi aktual lubrication point sebelum greasing/perbaikan.','Kondisi aktual lubrication point sebelum greasing/perbaikan.','Actual lubrication-point condition before greasing/repair.'],
      ['Belum ada foto BEFORE','Belum ada foto BEFORE','No BEFORE photo yet'], ['📷 Camera','📷 Kamera','📷 Camera'], ['🖼 Gallery','🖼 Galeri','🖼 Gallery'],
      ['Remove BEFORE Photo','Hapus Foto BEFORE','Remove BEFORE Photo'], ['AFTER — Post Greasing/Repair','AFTER — Setelah Greasing/Perbaikan','AFTER — Post Greasing/Repair'],
      ['Kondisi lubrication point setelah grease application atau corrective action.','Kondisi lubrication point setelah aplikasi grease atau corrective action.','Lubrication-point condition after grease application or corrective action.'],
      ['Belum ada foto AFTER','Belum ada foto AFTER','No AFTER photo yet'], ['Remove AFTER Photo','Hapus Foto AFTER','Remove AFTER Photo'],
      ['Save Execution Evidence','Simpan Bukti Eksekusi','Save Execution Evidence'], ['Photo Evidence','Bukti Foto','Photo Evidence'],
      ['Dokumentasi pekerjaan lubrication.','Dokumentasi pekerjaan pelumasan.','Lubrication work documentation.'], ['Edit History Lubrication','Edit Riwayat Pelumasan','Edit Lubrication History'],
      ['Perbarui catatan pekerjaan pelumasan yang dipilih.','Perbarui catatan pekerjaan pelumasan yang dipilih.','Update the selected lubrication work record.'],
      ['Tanggal & Waktu','Tanggal & Waktu','Date & Time'], ['Titik Pelumasan','Titik Pelumasan','Lubrication Point'], ['Quantity','Quantity','Quantity'],
      ['Done','Selesai','Done'], ['Skipped','Tidak Dapat Dikerjakan','Skipped'], ['Pending','Menunggu','Pending'], ['Teknisi','Teknisi','Technician'],
      ['Pilih salah satu dari dua metode identifikasi equipment.','Pilih salah satu dari dua metode identifikasi equipment.','Choose one of the two equipment identification methods.'],
      ['Hanya tersedia','Hanya tersedia','Only'], ['2 pilihan','2 pilihan','2 options'],
      ['scan QR Code langsung menggunakan kamera atau pilih foto QR Code dari galeri perangkat.','scan QR Code langsung menggunakan kamera atau pilih foto QR Code dari galeri perangkat.','scan a QR Code directly with the camera or choose a QR Code image from the device gallery.'],
      ['Kamera QR Otomatis','Kamera QR Otomatis','Automatic QR Camera'], ['Buka kamera belakang dan baca QR Code secara otomatis.','Buka kamera belakang dan baca QR Code secara otomatis.','Open the rear camera and read QR Codes automatically.'],
      ['Pilih dari Galeri','Pilih dari Galeri','Choose from Gallery'], ['Pilih foto atau screenshot QR Code dari perangkat.','Pilih foto atau screenshot QR Code dari perangkat.','Choose a QR Code photo or screenshot from the device.'],
      ['Menyiapkan kamera belakang...','Menyiapkan kamera belakang...','Preparing rear camera...'], ['Posisikan QR Code di dalam kotak. Scanner akan membaca otomatis.','Posisikan QR Code di dalam kotak. Scanner akan membaca otomatis.','Position the QR Code inside the frame. The scanner will read it automatically.'], ['Foto QR Code','Foto QR Code','QR Code Photo'],
      ['Pilih Ulang','Pilih Ulang','Choose Again'], ['Pilih Kamera atau Foto dari Galeri untuk mengidentifikasi equipment.','Pilih Kamera atau Foto dari Galeri untuk mengidentifikasi equipment.','Choose Camera or a Gallery Photo to identify equipment.'],
      ['Tutup','Tutup','Close'], ['QR Code Equipment','QR Code Equipment','Equipment QR Code'], ['Scan QR ini untuk mengidentifikasi equipment berdasarkan Nomor Unit.','Scan QR ini untuk mengidentifikasi equipment berdasarkan Nomor Unit.','Scan this QR to identify equipment by Unit Number.'],
      ['Lokasi: -','Lokasi: -','Location: -'], ['QR dapat dibaca Google Lens/kamera HP. Jika aplikasi online, QR akan membuka detail equipment melalui deep-link.','QR dapat dibaca Google Lens/kamera HP. Jika aplikasi online, QR akan membuka detail equipment melalui deep-link.','The QR can be read with Google Lens or a phone camera. If the app is online, it opens equipment details via a deep link.'],
      ['⬇ Download PNG','⬇ Download PNG','⬇ Download PNG'], ['🖨 Cetak Label','🖨 Cetak Label','🖨 Print Label'],
      ['Pelumasan per Komponen','Kapasitas Greasing Point','Pelumasan per Komponen'],
      ['Kapasitas referensi PDF, bukan otomatis dosis top-up. Baca catatan tiap komponen.','Kapasitas referensi PDF, bukan otomatis dosis top-up. Baca catatan tiap komponen.','Reference grease quantity for each point.'],
      ['Titik grease','Greasing Point Wajib','Titik greases'], ['Total Lubrication Point','Total Titik Pelumasan','Total Lubrication Points'],
      ['QR Equipment','QR Equipment','Equipment QR'], ['QR unik unit ini. Baca QR secara offline melalui menu Scan QR.','QR unik unit ini. Baca QR secara offline melalui menu Scan QR.','Scan with the QR Camera or choose a Gallery Photo from the Identify Equipment menu.'],
      ['▣ View Equipment QR','▣ Lihat QR Equipment','▣ View Equipment QR'], ['✏ Edit Technical Data','✏ Edit Data Teknis','✏ Edit Technical Data'], ['🗑 Delete','🗑 Hapus','🗑 Delete'],
      ['Belum diinput','Belum diinput','Not entered'], ['Belum ada greasing point terdaftar.','Belum ada greasing point terdaftar.','No greasing points registered yet.'],
      ['Stock di bawah minimum','Stok di bawah minimum','Stock below minimum'], ['Stock tersedia','Stok tersedia','Stock available'],
      ['Stock Saat Ini','Stok Saat Ini','Current Stock'], ['Selisih','Selisih','Difference'], ['✏ Edit','✏ Edit','✏ Edit'], ['🗑 Hapus','🗑 Hapus','🗑 Delete'],
      ['Tidak ada route yang jatuh tempo.','Tidak ada route yang jatuh tempo.','No routes are due.'], ['Data lubricant tidak ditemukan.','Data lubricant tidak ditemukan.','Lubricant data not found.'],
      ['Tidak ada grease/oil yang cocok. Coba nama produk, brand, grade, atau application lain.','Tidak ada grease/oil yang cocok. Coba nama produk, brand, grade, atau application lain.','No matching grease/oil found. Try another product name, brand, grade, or application.'],
      ['Belum ada history.','Belum ada riwayat.','No history yet.'], ['optional','opsional','optional'], ['required','wajib','required'],
      ['✓ Review Evidence','✓ Tinjau Bukti','✓ Review Evidence'],
      ['Not specified','Belum ditentukan','Not specified'], ['No TEMP','Tidak ada TEMP','No TEMP'], ['No BEFORE','Tidak ada BEFORE','No BEFORE'], ['No AFTER','Tidak ada AFTER','No AFTER'],
      ['Tampilkan password','Tampilkan password','Show password'], ['Sembunyikan password','Sembunyikan password','Hide password'],
      ['Buka profil pengguna','Buka profil pengguna','Open user profile'], ['Buka menu','Buka menu','Open menu'],
      ['Cari grease dan oil stock','Cari stock grease dan oil','Search grease and oil stock'], ['Sugesti grease dan oil','Sugesti grease dan oil','Grease and oil suggestions'],
      ['Cari history lubrication','Cari riwayat pelumasan','Search lubrication history'], ['Sugesti history lubrication','Sugesti riwayat pelumasan','Lubrication history suggestions'],
      ['Bahasa aplikasi / Application language','Bahasa aplikasi / Application language','Application language'],
      ['Anda telah keluar dari akun.','Anda telah keluar dari akun.','You have signed out.'], ['Username atau password tidak sesuai.','Username atau password tidak sesuai.','Incorrect username or password.'],
      ['Penyimpanan browser penuh. Hapus foto lama atau gunakan foto berukuran lebih kecil.','Penyimpanan browser penuh. Hapus foto lama atau gunakan foto berukuran lebih kecil.','Browser storage is full. Delete old photos or use smaller images.'],
      ['Password saat ini tidak sesuai.','Password saat ini tidak sesuai.','Current password is incorrect.'], ['Password baru minimal 6 karakter.','Password baru minimal 6 karakter.','New password must be at least 6 characters.'],
      ['Konfirmasi password baru tidak sama.','Konfirmasi password baru tidak sama.','New password confirmation does not match.'], ['Username tidak boleh kosong.','Username tidak boleh kosong.','Username cannot be empty.'],
      ['Profil pengguna berhasil diperbarui.','Profil pengguna berhasil diperbarui.','User profile updated successfully.'], ['Perubahan profil dibatalkan.','Perubahan profil dibatalkan.','Profile changes canceled.'],
      ['Equipment tidak ditemukan.','Equipment tidak ditemukan.','Equipment not found.'], ['QR Code belum siap.','QR Code belum siap.','QR Code is not ready.'],
      ['Pop-up diblokir browser. Izinkan pop-up untuk mencetak label.','Pop-up diblokir browser. Izinkan pop-up untuk mencetak label.','The browser blocked the pop-up. Allow pop-ups to print the label.'],
      ['Equipment berhasil dihapus.','Equipment berhasil dihapus.','Equipment deleted successfully.'], ['Lubricant berhasil dihapus.','Lubricant berhasil dihapus.','Lubricant deleted successfully.'], ['History berhasil dihapus.','Riwayat berhasil dihapus.','History deleted successfully.'],
      ['Foto belum tersedia.','Foto belum tersedia.','Photo not available yet.'], ['Buka lubrication point terlebih dahulu.','Buka lubrication point terlebih dahulu.','Open a lubrication point first.'],
      ['Pengambilan foto dibatalkan. Form tetap pada lubrication point yang sama.','Pengambilan foto dibatalkan. Form tetap pada lubrication point yang sama.','Photo capture canceled. The form remains on the same lubrication point.'],
      ['Reason wajib diisi untuk lubrication point yang tidak dapat dikerjakan.','Reason wajib diisi untuk lubrication point yang tidak dapat dikerjakan.','A reason is required for a lubrication point that cannot be executed.'],
      ['Foto BEFORE kondisi aktual wajib dilampirkan.','Foto BEFORE kondisi aktual wajib dilampirkan.','A BEFORE photo of the actual condition is required.'], ['Foto AFTER setelah greasing/perbaikan wajib dilampirkan.','Foto AFTER setelah greasing/perbaikan wajib dilampirkan.','An AFTER photo following greasing/repair is required.'],
      ['Execution status dan photo evidence berhasil disimpan.','Status eksekusi dan bukti foto berhasil disimpan.','Execution status and photo evidence saved successfully.'],
      ['Tag equipment sudah terdaftar.','Tag equipment sudah terdaftar.','Equipment tag is already registered.'], ['Nomor unit sudah terdaftar.','Nomor unit sudah terdaftar.','Unit number is already registered.'],
      ['Equipment berhasil diperbarui.','Equipment berhasil diperbarui.','Equipment updated successfully.'], ['Equipment baru berhasil ditambahkan.','Equipment baru berhasil ditambahkan.','New equipment added successfully.'],
      ['Lubricant tidak ditemukan.','Lubricant tidak ditemukan.','Lubricant not found.'], ['Lubricant berhasil diperbarui.','Lubricant berhasil diperbarui.','Lubricant updated successfully.'], ['Lubricant berhasil ditambahkan.','Lubricant berhasil ditambahkan.','Lubricant added successfully.'],
      ['History tidak ditemukan.','Riwayat tidak ditemukan.','History not found.'], ['History berhasil diperbarui.','Riwayat berhasil diperbarui.','History updated successfully.'],
      ['Foto tidak dapat diproses.','Foto tidak dapat diproses.','Photo could not be processed.'], ['Gambar tidak dapat dibuka','Gambar tidak dapat dibuka','Image could not be opened'],
      ['File harus berupa gambar JPG, PNG, WEBP, atau BMP.','File harus berupa gambar JPG, PNG, WEBP, atau BMP.','File must be a JPG, PNG, WEBP, or BMP image.'],
      ['Ukuran gambar terlalu besar. Gunakan gambar maksimal 20 MB.','Ukuran gambar terlalu besar. Gunakan gambar maksimal 20 MB.','Image is too large. Use an image up to 20 MB.'],
      ['Memproses gambar dan mencari QR Code…','Memproses gambar dan mencari QR Code…','Processing image and searching for QR Code…'],
      ['Pembaca QR belum tersedia di browser ini. Pastikan internet aktif saat pertama membuka aplikasi, lalu coba Kamera atau Galeri kembali.','Pembaca QR belum tersedia di browser ini. Pastikan internet aktif saat pertama membuka aplikasi, lalu coba Kamera atau Galeri kembali.','QR reader is not available in this browser yet. Ensure internet access on the first app launch, then try Camera or Gallery again.'],
      ['QR belum terbaca. Pilih foto yang lebih dekat, terang, tegak, dan tidak terpotong.','QR belum terbaca. Pilih foto yang lebih dekat, terang, tegak, dan tidak terpotong.','QR could not be read. Choose a closer, brighter, upright, uncropped photo.'],
      ['Gambar tidak dapat diproses. Coba pilih foto QR Code lain dari galeri.','Gambar tidak dapat diproses. Coba pilih foto QR Code lain dari galeri.','Image could not be processed. Try another QR Code photo from the gallery.'],
      ['QR Code belum menghasilkan kode equipment yang valid.','QR Code belum menghasilkan kode equipment yang valid.','The QR Code did not produce a valid equipment code.'],
      ['Masukkan username','Masukkan username','Enter username'], ['Masukkan password','Masukkan password','Enter password'],
      ['Cari nomor unit, alat, atau lokasi...','Cari nomor unit, alat, atau lokasi...','Search unit number, equipment, or location...'],
      ['Cari Equipment No., description, component, brand, lubricant...','Cari Equipment No., description, component, brand, lubricant...','Search Equipment No., description, component, brand, or lubricant...'],
      ['Cari grease/oil, brand, grade, atau application...','Cari grease/oil, brand, grade, atau application...','Search grease/oil, brand, grade, or application...'],
      ['Cari equipment, titik, lubricant, teknisi, status, atau tanggal...','Cari equipment, titik, lubricant, teknisi, status, atau tanggal...','Search equipment, point, lubricant, technician, status, or date...'],
      ['Isi hanya saat mengganti password','Isi hanya saat mengganti password','Fill only when changing the password'], ['Minimal 6 karakter','Minimal 6 karakter','Minimum 6 characters'], ['Ulangi password baru','Ulangi password baru','Repeat the new password'],
      ['Motor listrik 380 V, 55 kW','Motor listrik 380 V, 55 kW','Electric motor 380 V, 55 kW'], ['Contoh: 62','Contoh: 62','Example: 62'], ['Contoh: 120 liter','Contoh: 120 liter','Example: 120 liters'],
      ['Contoh: 40 gram / service','Contoh: 40 gram / service','Example: 40 grams / service'],
      ['Satu titik per baris. Format: Nama titik | Quantity\nDrive Pulley Bearing DE | 20 gram\nDrive Pulley Bearing NDE | 20 gram','Satu titik per baris. Format: Nama titik | Quantity\nDrive Pulley Bearing DE | 20 gram\nDrive Pulley Bearing NDE | 20 gram','One point per line. Format: Point name | Quantity\nDrive Pulley Bearing DE | 20 grams\nDrive Pulley Bearing NDE | 20 grams'],
      ['Contoh: 20 gram / 0.5 liter','Contoh: 20 gram / 0.5 liter','Example: 20 grams / 0.5 liters'],
      ['Contoh: bearing normal, seal leakage, abnormal noise, contamination, fitting blocked...','Contoh: bearing normal, seal leakage, abnormal noise, contamination, fitting blocked...','Example: bearing normal, seal leakage, abnormal noise, contamination, fitting blocked...'],
      ['Contoh: guard tidak dapat dibuka, equipment masih running, nipple grease rusak...','Contoh: guard tidak dapat dibuka, equipment masih running, nipple grease rusak...','Example: guard cannot be opened, equipment is still running, grease nipple is damaged...'],
      ['Login Smart Lubrication Management','Login Smart Lubrication Management','Smart Lubrication Management Login'], ['Navigasi utama','Navigasi utama','Main navigation'],
      ['Pesan pengingat pelumasan','Pesan pengingat pelumasan','Lubrication reminder'], ['Scan QR Code equipment','Scan QR Code equipment','Scan equipment QR Code'],
      ['Navigasi cepat mobile','Navigasi cepat mobile','Quick mobile navigation'], ['Tutup form equipment','Tutup form equipment','Close equipment form'],
      ['Tutup form lubricant','Tutup form lubricant','Close lubricant form'], ['Tutup update titik','Tutup update titik','Close point update'], ['Tutup foto','Tutup foto','Close photo'],
      ['Tutup form history','Tutup form history','Close history form'], ['Tutup identifikasi equipment','Tutup identifikasi equipment','Close equipment identification'],
      ['Tutup QR equipment','Tutup QR equipment','Close equipment QR'], ['QR Code equipment','QR Code equipment','Equipment QR Code'],
      ['Scan QR Equipment','Scan QR Equipment','Scan Equipment QR'], ['Pilih Kamera HP atau gambar QR dari galeri.','Pilih Kamera HP atau gambar QR dari galeri.','Choose the automatic camera or a QR image from the gallery.'],
      ['Pilih salah satu dari 2 metode di atas.','Pilih salah satu dari 2 metode di atas.','Choose one of the 2 methods above.'],
      ['Bebas dipilih','Bebas dipilih','Free selection'],
      ['Lubricant Specification','Spesifikasi Lubricant','Lubricant Specification'], ['Reference Quantity','Quantity Referensi','Reference Quantity'],
      ['Lubrication Interval','Interval Pelumasan','Lubrication Interval'],
      ['Foto tidak dipilih.','Foto tidak dipilih.','No photo selected.'], ['File harus berupa gambar.','File harus berupa gambar.','File must be an image.'],
      ['Ukuran foto maksimal 20 MB.','Ukuran foto maksimal 20 MB.','Maximum photo size is 20 MB.']
    ];

    const languageLookup = new Map();
    for (const [base, id, en] of languageEntries) {
      const record = {id, en};
      for (const alias of [base, id, en]) if (alias) languageLookup.set(alias, record);
    }

    function translateDynamicText(value, lang=currentLanguage) {
      let s = String(value ?? '');
      const exact = languageLookup.get(s);
      if (exact) return exact[lang] ?? s;
      let m;
      if (lang === 'en') {
        if ((m=s.match(/^Menampilkan (\d+)[–-](\d+) dari (\d+) equipment$/))) return `Showing ${m[1]}–${m[2]} of ${m[3]} equipment`;
        if ((m=s.match(/^(\d+) equipment$/))) return `${m[1]} equipment`;
        if ((m=s.match(/^Menampilkan (\d+)[–-](\d+) dari (\d+) record$/))) return `Showing ${m[1]}–${m[2]} of ${m[3]} records`;
        if ((m=s.match(/^(\d+) dari (\d+) item$/))) return `${m[1]} of ${m[2]} items`;
        if ((m=s.match(/^(\d+) dari (\d+) record$/))) return `${m[1]} of ${m[2]} records`;
        if ((m=s.match(/^(\d+) item$/))) return `${m[1]} items`;
        if ((m=s.match(/^(\d+) record$/))) return `${m[1]} records`;
        if ((m=s.match(/^(\d+) menit$/))) return `${m[1]} min`;
        if ((m=s.match(/^(\d+)\/(\d+) titik$/))) return `${m[1]}/${m[2]} points`;
        if ((m=s.match(/^(\d+) point$/))) return `${m[1]} points`;
        if ((m=s.match(/^Urutan wajib: (\d+)\/(\d+)$/))) return `Required sequence: ${m[1]}/${m[2]}`;
        if ((m=s.match(/^🔒 Step (\d+) Terkunci$/))) return `🔒 Step ${m[1]} Locked`;
        if ((m=s.match(/^📋 Execute Step (\d+)$/))) return `📋 Execute Step ${m[1]}`;
        if ((m=s.match(/^Hasil pencarian untuk “(.+)”\. Stock dan minimum ditampilkan pada setiap kartu\.$/))) return `Search results for “${m[1]}”. Current and minimum stock are shown on each card.`;
        if ((m=s.match(/^Hasil pencarian untuk “(.+)”\. Anda tetap dapat membuka foto, edit, atau menghapus record hasil pencarian\.$/))) return `Search results for “${m[1]}”. You can still open photos, edit, or delete matching records.`;
        if ((m=s.match(/^Tidak ada sugesti untuk (.+)\.$/))) return `No suggestions for ${m[1]}.`;
        if ((m=s.match(/^Tidak ada sugesti history untuk (.+)\.$/))) return `No history suggestions for ${m[1]}.`;
        if ((m=s.match(/^History tidak ditemukan untuk “(.+)”\.$/))) return `No history found for “${m[1]}”.`;
        if ((m=s.match(/^Nomor Unit: (.+)$/))) return `Unit Number: ${m[1]}`;
        if ((m=s.match(/^Qty \/ Point: (.+)$/))) return `Kapasitas PDF: ${m[1]}`;
        if ((m=s.match(/^Perbarui data (.+) tanpa membuat equipment baru\.$/))) return `Update ${m[1]} without creating new equipment.`;
        if ((m=s.match(/^Perbarui master (.+) tanpa membuat data baru\.$/))) return `Update ${m[1]} without creating a new record.`;
        if ((m=s.match(/^(.+) ditemukan melalui (.+)\.$/))) return `${m[1]} found via ${m[2]}.`;
        if ((m=s.match(/^Equipment ditemukan: (.+)$/))) return `Equipment found: ${m[1]}`;
        if ((m=s.match(/^“(.+)” berhasil dibaca, tetapi equipment tersebut belum terdaftar\.$/))) return `“${m[1]}” was read successfully, but the equipment is not registered.`;
        if ((m=s.match(/^Selamat datang, (.+)\.$/))) return `Welcome, ${m[1]}.`;
      } else {
        if ((m=s.match(/^Showing (\d+)[–-](\d+) of (\d+) equipment$/))) return `Menampilkan ${m[1]}–${m[2]} dari ${m[3]} equipment`;
        if ((m=s.match(/^Showing (\d+)[–-](\d+) of (\d+) records$/))) return `Menampilkan ${m[1]}–${m[2]} dari ${m[3]} record`;
        if ((m=s.match(/^(\d+) of (\d+) items$/))) return `${m[1]} dari ${m[2]} item`;
        if ((m=s.match(/^(\d+) of (\d+) records$/))) return `${m[1]} dari ${m[2]} record`;
        if ((m=s.match(/^(\d+) items$/))) return `${m[1]} item`;
        if ((m=s.match(/^(\d+) records$/))) return `${m[1]} record`;
        if ((m=s.match(/^(\d+) min$/))) return `${m[1]} menit`;
        if ((m=s.match(/^(\d+)\/(\d+) points$/))) return `${m[1]}/${m[2]} titik`;
        if ((m=s.match(/^(\d+) points$/))) return `${m[1]} point`;
        if ((m=s.match(/^Required sequence: (\d+)\/(\d+)$/))) return `Urutan wajib: ${m[1]}/${m[2]}`;
        if ((m=s.match(/^🔒 Step (\d+) Locked$/))) return `🔒 Step ${m[1]} Terkunci`;
        if ((m=s.match(/^Search results for “(.+)”\. Current and minimum stock are shown on each card\.$/))) return `Hasil pencarian untuk “${m[1]}”. Stock dan minimum ditampilkan pada setiap kartu.`;
        if ((m=s.match(/^Search results for “(.+)”\. You can still open photos, edit, or delete matching records\.$/))) return `Hasil pencarian untuk “${m[1]}”. Anda tetap dapat membuka foto, edit, atau menghapus record hasil pencarian.`;
        if ((m=s.match(/^No history found for “(.+)”\.$/))) return `History tidak ditemukan untuk “${m[1]}”.`;
        if ((m=s.match(/^Unit Number: (.+)$/))) return `Nomor Unit: ${m[1]}`;
        if ((m=s.match(/^Update (.+) without creating new equipment\.$/))) return `Perbarui data ${m[1]} tanpa membuat equipment baru.`;
        if ((m=s.match(/^Update (.+) without creating a new record\.$/))) return `Perbarui master ${m[1]} tanpa membuat data baru.`;
        if ((m=s.match(/^Welcome, (.+)\.$/))) return `Selamat datang, ${m[1]}.`;
      }
      return s;
    }

    function translatePreservingSpace(raw) {
      const m = String(raw ?? '').match(/^(\s*)([\s\S]*?)(\s*)$/);
      if (!m || !m[2]) return raw;
      return m[1] + translateDynamicText(m[2]) + m[3];
    }

    function translateTree(root=document.body) {
      if (!root) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          const tag = node.parentElement?.tagName;
          if (!tag || tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
          return node.nodeValue?.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
      });
      const nodes = [];
      while (walker.nextNode()) nodes.push(walker.currentNode);
      for (const node of nodes) {
        const next = translatePreservingSpace(node.nodeValue);
        if (next !== node.nodeValue) node.nodeValue = next;
      }
      const elements = root.nodeType === 1 ? [root, ...root.querySelectorAll('[placeholder],[title],[aria-label]')] : [...root.querySelectorAll('[placeholder],[title],[aria-label]')];
      for (const el of elements) {
        for (const attr of ['placeholder','title','aria-label']) {
          if (!el.hasAttribute?.(attr)) continue;
          const old = el.getAttribute(attr);
          const next = translateDynamicText(old);
          if (next !== old) el.setAttribute(attr, next);
        }
      }
    }

    const tx = value => translateDynamicText(value, currentLanguage);

    function syncLanguageSelectors() {
      const value = currentLanguage === 'en' ? 'en' : 'id';
      const top = $('#languageSelect'); if (top && top.value !== value) top.value = value;
      const login = $('#loginLanguageSelect'); if (login && login.value !== value) login.value = value;
    }

    function setLanguage(language, persist=true) {
      currentLanguage = language === 'en' ? 'en' : 'id';
      document.documentElement.lang = currentLanguage === 'en' ? 'en' : 'id';
      if (persist) { try { localStorage.setItem(languageStorageKey, currentLanguage); } catch (_) {} }
      syncLanguageSelectors();
      translateTree(document.body);
    }

    $('#languageSelect')?.addEventListener('change', e => setLanguage(e.currentTarget.value));
    $('#loginLanguageSelect')?.addEventListener('change', e => setLanguage(e.currentTarget.value));
    syncLanguageSelectors();

    // Equipment performance cache. The old renderer rebuilt point-search strings and
    // regenerated every equipment card + QR code on every keystroke/page open.
    let equipmentSearchCache = new WeakMap();
    let equipmentPage = 1;
    const equipmentPageSize = 18;
    let equipmentSearchTimer = null;
    let equipmentQrObserver = null;
    const equipmentSearchText = e => {
      let cached = equipmentSearchCache.get(e);
      if (cached) return cached;
      const pointSearch = (e.points || []).map(p => `${p.name || ''} ${p.lubricant || ''} ${p.qty || ''}`).join(' ');
      cached = `${e.tag || ''} ${e.unitNumber || ''} ${e.name || ''} ${e.manufactureYear || ''} ${e.powerSource || ''} ${e.operationalStatus || ''} ${e.area || ''} ${e.grease || ''} ${e.greaseCapacity || ''} ${e.oil || ''} ${e.oilCapacity || ''} ${pointSearch}`.toLowerCase();
      equipmentSearchCache.set(e, cached);
      return cached;
    };
    const resetEquipmentSearchCache = () => { equipmentSearchCache = new WeakMap(); };

    const accountStorageKey = 'slm_local_account_v2_wahyu_nh2290';
    const persistentSessionKey = 'slm_login_remembered_v1';
    const tabSessionKey = 'slm_login_session_v1';
    const uiPageSessionKey = 'slm_active_page_v2';
    const routeDraftSessionKey = 'slm_route_execution_draft_v2';
    const cameraPermissionReadyKey = 'slm_camera_permission_ready_v1';
    const cameraPermissionDeferredKey = 'slm_camera_permission_deferred_tab_v1';
    const defaultAccount = {
      username: 'wahyu',
      password: 'SLM123',
      fullName: 'Wahyu Setiyonyoto',
      role: 'Senior Mechanical Boilermaker',
      employeeId: 'NH2290',
      workArea: 'Fixed Plant',
      email: '',
      phone: ''
    };
    let account;
    try { account = {...defaultAccount, ...(JSON.parse(localStorage.getItem(accountStorageKey)) || {})}; }
    catch (_) { account = {...defaultAccount}; }
    const saveAccount = () => localStorage.setItem(accountStorageKey, JSON.stringify(account));
    const initials = name => String(name || 'User').trim().split(/\s+/).slice(0,2).map(x => x[0] || '').join('').toUpperCase() || 'U';
    const isLoggedIn = () => localStorage.getItem(persistentSessionKey) === 'true' || sessionStorage.getItem(tabSessionKey) === 'true';

    function updateAccountUI() {
      const shortName = String(account.fullName || account.username).trim().split(/\s+/)[0] || account.username;
      const avatarText = initials(account.fullName);
      $('#sidebarAvatar').textContent = avatarText;
      $('#sidebarUserName').textContent = account.fullName;
      $('#sidebarUserRole').textContent = account.role;
      $('#topbarAvatar').textContent = avatarText;
      $('#topbarUserName').textContent = shortName;
      $('#routeTechnicianName').textContent = account.fullName;
      $('#profileAvatar').textContent = avatarText;
      $('#profileDisplayName').textContent = account.fullName;
      $('#profileDisplayRole').textContent = account.role;
      $('#profileEmployeeId').textContent = account.employeeId || '-';
      $('#profileWorkArea').textContent = account.workArea || '-';
      $('#profileUsernameText').textContent = account.username;
    }

    function fillProfileForm() {
      const form = $('#profileForm');
      form.elements.fullName.value = account.fullName || '';
      form.elements.role.value = account.role || '';
      form.elements.employeeId.value = account.employeeId || '';
      form.elements.workArea.value = account.workArea || '';
      form.elements.email.value = account.email || '';
      form.elements.phone.value = account.phone || '';
      form.elements.username.value = account.username || '';
      form.elements.currentPassword.value = '';
      form.elements.newPassword.value = '';
      form.elements.confirmPassword.value = '';
    }

    function renderProfile() {
      updateAccountUI();
      fillProfileForm();
    }

    function showLogin(message='') {
      $('#appShell').hidden = true;
      $('#loginScreen').hidden = false;
      $('#sidebar').classList.remove('open');
      $('#loginMessage').textContent = message;
      $('#loginForm').reset();
      $('#loginUsername').value = account.username === defaultAccount.username ? defaultAccount.username : '';
      $('#loginHelp').innerHTML = account.username === defaultAccount.username && account.password === defaultAccount.password
        ? 'Akun awal: <b>wahyu</b> &nbsp;|&nbsp; Password: <b>SLM123</b>'
        : 'Gunakan username dan password yang telah disimpan pada halaman profil.';
      translateTree($('#loginScreen'));
      setTimeout(() => $('#loginUsername').focus(), 50);
    }

    function handleDeepLink() {
      const hash = String(location.hash || '');
      const match = hash.match(/^#equipment=([^&]+)/i);
      if (!match) return;
      const unit = decodeURIComponent(match[1] || '').trim();
      const equipment = state.equipment.find(e => String(e.unitNumber).toLowerCase() === unit.toLowerCase() || String(e.tag).toLowerCase() === unit.toLowerCase());
      if (!equipment) return;
      goPage('equipment');
      $('#equipmentSearch').value = equipment.unitNumber;
      renderEquipment();
      setTimeout(() => {
        const card = [...document.querySelectorAll('.equipment-card')].find(c => c.dataset.tag === equipment.tag);
        if (card) { card.classList.add('qr-match'); card.scrollIntoView({behavior:'smooth', block:'center'}); setTimeout(()=>card.classList.remove('qr-match'),2600); }
        openEquipmentDetail(equipment);
      }, 140);
    }

    function openApplication() {
      $('#loginScreen').hidden = true;
      $('#appShell').hidden = false;
      updateAccountUI();
      const savedPage = sessionStorage.getItem(uiPageSessionKey);
      const allowedPage = (savedPage === 'lubricationDatabase' || savedPage === 'equipment') ? savedPage : 'equipment';
      goPage(document.getElementById(allowedPage) ? allowedPage : 'equipment');
      // Jika browser me-reload halaman setelah kamera/galeri, kembalikan operator ke titik route yang sama.
      setTimeout(() => restorePointDraftSession(), 80);
      setTimeout(() => handleDeepLink(), 120);
    }

    function logoutAccount() {
      localStorage.removeItem(persistentSessionKey);
      sessionStorage.removeItem(tabSessionKey);
      showLogin('Anda telah keluar dari akun.');
    }

    const toast = (message) => {
      const el = $('#toast'); el.textContent = tx(message); el.classList.add('show');
      clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2300);
    };

    async function getCameraPermissionState() {
      if (!navigator.permissions?.query) return 'unknown';
      try {
        const result = await navigator.permissions.query({name:'camera'});
        return result?.state || 'unknown';
      } catch (_) {
        return 'unknown';
      }
    }

    function setCameraPermissionSetupStatus(message, type='') {
      const el = $('#cameraPermissionStatus');
      if (!el) return;
      el.textContent = message;
      el.className = `camera-permission-status${type ? ' ' + type : ''}`;
    }

    async function maybeShowFirstUseCameraPermission() {
      const dialog = $('#cameraPermissionDialog');
      if (!dialog || dialog.open || $('#loginScreen')?.hidden === false) return;

      const permissionState = await getCameraPermissionState();
      if (permissionState === 'granted') {
        localStorage.setItem(cameraPermissionReadyKey, 'granted');
        sessionStorage.removeItem(cameraPermissionDeferredKey);
        return;
      }

      // If the browser cannot expose getUserMedia in the current context, still
      // show a clear first-use explanation instead of failing silently later.
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraPermissionSetupStatus('Browser pada mode ini belum menyediakan akses kamera. Buka aplikasi melalui Chrome pada HTTPS agar izin kamera dapat diberikan.', 'error');
        $('#grantCameraPermissionBtn').disabled = true;
        if (!dialog.open) dialog.showModal();
        return;
      }

      // "Nanti" suppresses only for this tab/session. The setup will be offered
      // again on the next fresh use until camera permission is actually granted.
      if (sessionStorage.getItem(cameraPermissionDeferredKey) === 'true') return;

      $('#grantCameraPermissionBtn').disabled = false;
      if (permissionState === 'denied') {
        setCameraPermissionSetupStatus('Izin kamera sedang diblokir oleh browser. Ubah izin Kamera situs ini menjadi Izinkan/Allow, lalu tekan Aktifkan Kamera lagi.', 'error');
      } else {
        setCameraPermissionSetupStatus('Kamera belum diaktifkan untuk aplikasi ini. Aktifkan sekarang agar QR Scanner siap digunakan.');
      }
      if (!dialog.open) dialog.showModal();
    }

    async function grantFirstUseCameraPermission() {
      const btn = $('#grantCameraPermissionBtn');
      if (!btn || btn.disabled) return;
      btn.disabled = true;
      const oldText = btn.textContent;
      btn.textContent = 'Mengaktifkan…';
      setCameraPermissionSetupStatus('Menunggu izin kamera dari browser HP…', 'loading');

      try {
        // This call is deliberately made directly from the user's button press,
        // which is the most reliable way for mobile browsers to display the
        // native camera permission prompt.
        const stream = await requestRearCameraStream();
        stopMediaStream(stream);
        localStorage.setItem(cameraPermissionReadyKey, 'granted');
        sessionStorage.removeItem(cameraPermissionDeferredKey);
        setCameraPermissionSetupStatus('✓ Kamera sudah diizinkan. QR Scanner Equipment siap digunakan.', 'success');
        btn.textContent = '✓ Kamera Siap';
        setTimeout(() => {
          const dialog = $('#cameraPermissionDialog');
          if (dialog?.open) dialog.close();
          btn.disabled = false;
          btn.textContent = oldText;
          toast('Izin kamera aktif. QR Scanner siap digunakan.');
        }, 700);
      } catch (err) {
        localStorage.removeItem(cameraPermissionReadyKey);
        const name = String(err?.name || '');
        if (name === 'NotAllowedError' || name === 'SecurityError') {
          setCameraPermissionSetupStatus('Izin kamera belum diberikan atau sedang diblokir. Pada browser HP, buka izin situs → Kamera → Izinkan, lalu coba lagi.', 'error');
        } else if (!window.isSecureContext && location.protocol !== 'file:') {
          setCameraPermissionSetupStatus('Akses kamera membutuhkan HTTPS. Jalankan aplikasi dari alamat HTTPS, kemudian aktifkan kamera kembali.', 'error');
        } else {
          setCameraPermissionSetupStatus(describeCameraError(err), 'error');
        }
        btn.disabled = false;
        btn.textContent = oldText;
      }
    }

    function goPage(id) {
      $$('.page').forEach(p => p.classList.toggle('active', p.id === id));
      try { sessionStorage.setItem(uiPageSessionKey, id); } catch (_) {}
      $$('[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === id));
      $('#sidebar').classList.remove('open');
      $('#sidebarOverlay')?.classList.remove('open');
      window.scrollTo({top:0, behavior:'smooth'});
      if (id === 'equipment') renderEquipment();
      if (id === 'kpiDetail') renderKpiDetail();
      if (id === 'lubricationDatabase') renderLubricationDatabase();
      if (id === 'route') renderRoute();
      if (id === 'lubricants') renderLubricants();
      if (id === 'history') renderHistory();
      if (id === 'profile') renderProfile();
      translateTree(document.getElementById(id));
    }
    $$('[data-page]').forEach(btn => btn.addEventListener('click', () => goPage(btn.dataset.page)));
    $$('[data-go]').forEach(btn => btn.addEventListener('click', () => goPage(btn.dataset.go)));
    $$('[data-back]').forEach(btn => btn.addEventListener('click', () => goPage(btn.dataset.back || 'dashboard')));
    window.addEventListener('hashchange', handleDeepLink);
    function toggleMobileMenu(force) {
      const open = typeof force === 'boolean' ? force : !$('#sidebar').classList.contains('open');
      $('#sidebar').classList.toggle('open', open);
      $('#sidebarOverlay').classList.toggle('open', open);
      $('#sidebarOverlay').setAttribute('aria-hidden', String(!open));
    }
    $('#menuBtn').addEventListener('click', () => toggleMobileMenu());
    $('#sidebarOverlay').addEventListener('click', () => toggleMobileMenu(false));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMobileMenu(false); });

    const sourceLogo = $('.brand-logo img');
    if (sourceLogo && !$('#loginLogoMount').firstChild) $('#loginLogoMount').append(sourceLogo.cloneNode(true));

    $('#toggleLoginPassword').addEventListener('click', () => {
      const input = $('#loginPassword');
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      $('#toggleLoginPassword').textContent = tx(show ? 'Sembunyi' : 'Lihat');
      $('#toggleLoginPassword').setAttribute('aria-label', tx(show ? 'Sembunyikan password' : 'Tampilkan password'));
    });

    $('#loginForm').addEventListener('submit', e => {
      e.preventDefault();
      const username = $('#loginUsername').value.trim();
      const password = $('#loginPassword').value;
      if (username !== account.username || password !== account.password) {
        $('#loginMessage').textContent = tx('Username atau password tidak sesuai.');
        $('#loginPassword').select();
        return;
      }
      const remember = $('#rememberLogin').checked;
      if (remember) {
        localStorage.setItem(persistentSessionKey, 'true');
        sessionStorage.removeItem(tabSessionKey);
      } else {
        sessionStorage.setItem(tabSessionKey, 'true');
        localStorage.removeItem(persistentSessionKey);
      }
      $('#loginMessage').textContent = '';
      openApplication();
      toast(`Selamat datang, ${account.fullName}.`);

    });

    $$('[data-logout]').forEach(btn => btn.addEventListener('click', () => {
      if (confirm('Keluar dari akun sekarang? Data aplikasi tetap tersimpan.')) logoutAccount();
    }));

    $('#profileForm').addEventListener('submit', e => {
      e.preventDefault();
      const form = e.currentTarget;
      if (!form.reportValidity()) return;
      const fd = new FormData(form);
      const currentPassword = String(fd.get('currentPassword') || '');
      const newPassword = String(fd.get('newPassword') || '');
      const confirmPassword = String(fd.get('confirmPassword') || '');
      if (newPassword || currentPassword || confirmPassword) {
        if (currentPassword !== account.password) { toast('Password saat ini tidak sesuai.'); form.elements.currentPassword.focus(); return; }
        if (newPassword.length < 6) { toast('Password baru minimal 6 karakter.'); form.elements.newPassword.focus(); return; }
        if (newPassword !== confirmPassword) { toast('Konfirmasi password baru tidak sama.'); form.elements.confirmPassword.focus(); return; }
      }
      const newUsername = String(fd.get('username') || '').trim();
      if (!newUsername) { toast('Username tidak boleh kosong.'); return; }
      account = {
        ...account,
        fullName: String(fd.get('fullName') || '').trim(),
        role: String(fd.get('role') || '').trim(),
        employeeId: String(fd.get('employeeId') || '').trim(),
        workArea: String(fd.get('workArea') || '').trim(),
        email: String(fd.get('email') || '').trim(),
        phone: String(fd.get('phone') || '').trim(),
        username: newUsername,
        password: newPassword || account.password
      };
      saveAccount();
      renderProfile();
      toast('Profil pengguna berhasil diperbarui.');
    });

    $('#cancelProfileChanges').addEventListener('click', () => {
      fillProfileForm();
      toast('Perubahan profil dibatalkan.');
    });

    $('#grantCameraPermissionBtn').addEventListener('click', grantFirstUseCameraPermission);
    $('#postponeCameraPermissionBtn').addEventListener('click', () => {
      sessionStorage.setItem(cameraPermissionDeferredKey, 'true');
      $('#cameraPermissionDialog').close();
      toast('Setup kamera ditunda. Izin akan diminta kembali saat QR Scanner digunakan.');
    });
    $('#cameraPermissionDialog').addEventListener('cancel', e => {
      e.preventDefault();
      sessionStorage.setItem(cameraPermissionDeferredKey, 'true');
      $('#cameraPermissionDialog').close();
    });

    const allPoints = () => state.equipment.flatMap(eq => (eq.points || []).map(p => ({...p, equipment:eq})));
    const isGreasePoint = (eq, point) => String(point.lubricantType || '').trim().toUpperCase() === 'GREASE' || (!point.lubricantType && String(point.lubricant || '').trim().toLowerCase() === String(eq.grease || '').trim().toLowerCase());
    const greasePointsFor = eq => (eq.points || []).filter(p => isGreasePoint(eq, p));
    const lubricationPoints = () => state.equipment
      .flatMap(equipment => greasePointsFor(equipment).map(point => ({...point, equipment})))
      .sort((a,b) => String(a.equipment.tag || '').localeCompare(String(b.equipment.tag || ''), undefined, {numeric:true}) || String(a.name || '').localeCompare(String(b.name || '')));

    function filteredLubricationPoints() {
      const query = String($('#lubricationPointSearch')?.value || '').trim().toLowerCase();
      const area = String($('#lubricationPointAreaFilter')?.value || '').trim();
      const status = String($('#lubricationPointStatusFilter')?.value || '').trim();
      return lubricationPoints().filter(item => {
        const haystack = [item.equipment.tag, item.equipment.name, item.equipment.area, item.name, item.lubricant, item.qty, item.interval].join(' ').toLowerCase();
        return (!query || haystack.includes(query)) && (!area || item.equipment.area === area) && (!status || item.status === status);
      });
    }

    function refreshLubricationPointAreaFilter() {
      const select = $('#lubricationPointAreaFilter');
      if (!select) return;
      const current = select.value;
      const areas = [...new Set(lubricationPoints().map(item => item.equipment.area).filter(Boolean))].sort((a,b) => a.localeCompare(b, undefined, {numeric:true}));
      select.innerHTML = '<option value="">Semua Area</option>' + areas.map(area => `<option value="${esc(area)}">${esc(area)}</option>`).join('');
      if (areas.includes(current)) select.value = current;
    }
    const shownTechValue = value => String(value || '').trim() ? esc(value) : '<span class="tech-value-missing">Belum diinput</span>';
    function greasePointDetailsText(eq) {
      return greasePointsFor(eq).map(p => `${p.name} | ${p.qty || ''}`).join('\n');
    }
    function parseGreasePointDetails(text, grease, existingPoints=[]) {
      const existingByName = new Map(existingPoints.map(p => [String(p.name || '').trim().toLowerCase(), p]));
      return String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean).map((line, index) => {
        const parts = line.split('|');
        const name = String(parts[0] || `Greasing Point ${String(index+1).padStart(2,'0')}`).trim();
        const qty = String(parts.slice(1).join('|') || 'Sesuai standard').trim();
        const old = existingByName.get(name.toLowerCase());
        return {
          id: old?.id || `p${Date.now()}_${index}_${Math.random().toString(36).slice(2,6)}`,
          name, lubricant: grease, interval: old?.interval || '30 hari', qty,
          status: old?.status || 'Pending', evidence: old?.evidence || {before:'',after:''}
        };
      });
    }

    function renderDashboard() {
      const points = allPoints();
      const due = state.equipment.filter(e => e.status === 'Due').length;
      const overdue = state.equipment.filter(e => e.status === 'Overdue').length;
      const completed = points.filter(p => p.status === 'Done').length;
      const skipped = points.filter(p => p.status === 'Skipped').length;
      const pending = points.filter(p => p.status === 'Pending').length;
      const compliance = points.length ? Math.round(completed / points.length * 100) : 0;
      $('#kpiEquipment').textContent = state.equipment.length;
      $('#kpiPoints').textContent = points.length;
      $('#kpiDue').textContent = due;
      $('#kpiOverdue').textContent = overdue;
      $('#todayRouteCount').textContent = lubricationPoints().length;
      $('#complianceText').textContent = compliance + '%';
      $('#complianceDonut').style.background = `conic-gradient(#079455 ${compliance*3.6}deg, #e8edf3 0)`;
      $('#completedCount').textContent = completed;
      $('#pendingCount').textContent = pending;
      $('#missedCount').textContent = skipped + overdue;

      const preview = lubricationPoints().slice(0,4);
      $('#todayRouteList').innerHTML = preview.length ? preview.map(x => `
        <div class="route-preview-item"><div><strong>${esc(x.equipment.tag)} · ${esc(x.name)}</strong><small>${esc(x.equipment.area)} · ${esc(x.lubricant)}</small></div>
        <span class="status-badge ${statusClass(x.status)}">${esc(x.status)}</span></div>`).join('') : '<div class="empty-state">Tidak ada greasing point.</div>';

      const critical = [...state.equipment].sort((a,b) => ({Overdue:0,Due:1,Normal:2}[a.status]-({Overdue:0,Due:1,Normal:2}[b.status]))).slice(0,4);
      $('#criticalEquipment').innerHTML = critical.map(e => `<div class="critical-row"><div><strong>${esc(e.tag)} · ${esc(e.name)}</strong><small>${esc(e.area)} · Criticality ${esc(e.criticality)}</small></div><span class="status-badge status-${e.status.toLowerCase()}">${esc(e.status)}</span></div>`).join('');
      translateTree($('#dashboard'));
    }

    let kpiDetailMode = 'equipment';
    let kpiDetailPage = 1;
    const kpiDetailPageSize = 50;

    const kpiDetailConfig = {
      equipment: {
        title: 'Data Total Equipment',
        subtitle: 'Daftar seluruh equipment yang terdaftar di Smart Lubrication Management.',
        countLabel: 'Total Equipment'
      },
      points: {
        title: 'Data Titik Pelumasan',
        subtitle: 'Daftar seluruh lubrication point aktif beserta equipment, lubricant, interval, quantity, dan statusnya.',
        countLabel: 'Lubrication Points'
      },
      due: {
        title: 'Data Jatuh Tempo Hari Ini',
        subtitle: 'Equipment yang berstatus jatuh tempo dan harus dikerjakan hari ini.',
        countLabel: 'Due Today'
      },
      overdue: {
        title: 'Data Terlambat',
        subtitle: 'Equipment yang melewati jadwal pelumasan dan memerlukan prioritas.',
        countLabel: 'Overdue'
      }
    };

    function kpiEquipmentSearchText(e) {
      return [e.tag, e.unitNumber, e.name, e.area, e.criticality, e.status]
        .map(v => String(v || '').toLowerCase()).join(' ');
    }

    function kpiPointSearchText(item) {
      const p = item.point, e = item.equipment;
      return [e.tag, e.unitNumber, e.name, e.area, e.criticality, e.status, p.name, p.lubricant, p.lubricantType, p.interval, p.qty, p.status]
        .map(v => String(v || '').toLowerCase()).join(' ');
    }

    function getKpiDetailRows() {
      if (kpiDetailMode === 'points') {
        return allPoints().map(point => ({point, equipment: point.equipment}));
      }
      if (kpiDetailMode === 'due') return state.equipment.filter(e => e.status === 'Due');
      if (kpiDetailMode === 'overdue') return state.equipment.filter(e => e.status === 'Overdue');
      return state.equipment.slice();
    }

    function refreshKpiDetailAreaFilter() {
      const select = $('#kpiDetailAreaFilter');
      if (!select) return;
      const current = select.value;
      const areas = [...new Set(state.equipment.map(e => e.area).filter(Boolean))].sort();
      select.innerHTML = '<option value="">Semua Area</option>' + areas.map(a => `<option>${esc(a)}</option>`).join('');
      if (areas.includes(current)) select.value = current;
      translateTree(select);
    }

    function renderKpiDetail(resetPage=false) {
      const cfg = kpiDetailConfig[kpiDetailMode] || kpiDetailConfig.equipment;
      if (resetPage) kpiDetailPage = 1;
      $('#kpiDetailEyebrow').textContent = tx('Dashboard Detail');
      $('#kpiDetailTitle').textContent = tx(cfg.title);
      $('#kpiDetailSubtitle').textContent = tx(cfg.subtitle);
      $('#kpiDetailCountLabel').textContent = tx(cfg.countLabel);
      $('#kpiDetailSummaryNote').textContent = tx('Data mengikuti kondisi terbaru pada aplikasi.');
      refreshKpiDetailAreaFilter();

      const query = String($('#kpiDetailSearch')?.value || '').trim().toLowerCase();
      const area = $('#kpiDetailAreaFilter')?.value || '';
      let rows = getKpiDetailRows();

      if (kpiDetailMode === 'points') {
        rows = rows.filter(item => (!area || item.equipment.area === area) && (!query || kpiPointSearchText(item).includes(query)));
      } else {
        rows = rows.filter(e => (!area || e.area === area) && (!query || kpiEquipmentSearchText(e).includes(query)));
      }

      $('#kpiDetailCount').textContent = rows.length;
      const totalPages = Math.max(1, Math.ceil(rows.length / kpiDetailPageSize));
      kpiDetailPage = Math.min(Math.max(1, kpiDetailPage), totalPages);
      const start = (kpiDetailPage - 1) * kpiDetailPageSize;
      const visible = rows.slice(start, start + kpiDetailPageSize);

      if (kpiDetailMode === 'points') {
        $('#kpiDetailTableHead').innerHTML = `<tr><th>No.</th><th>Nomor Unit</th><th>Equipment</th><th>Area</th><th>Titik Pelumasan</th><th>Lubricant</th><th>Interval</th><th>Quantity</th><th>Status</th><th>Aksi</th></tr>`;
        $('#kpiDetailTableBody').innerHTML = visible.length ? visible.map((item, i) => {
          const p = item.point, e = item.equipment;
          return `<tr>
            <td>${start+i+1}</td>
            <td><b>${esc(e.unitNumber || e.tag || '-')}</b></td>
            <td><b>${esc(e.name || '-')}</b><div class="subtle">${esc(e.criticality || '-')} Criticality</div></td>
            <td>${esc(e.area || '-')}</td>
            <td><div class="point-name">${esc(p.name || 'Lubrication Point')}</div><div class="subtle">${esc(p.lubricantType || '-')}</div></td>
            <td>${esc(p.lubricant || '-')}</td>
            <td>${esc(p.interval || '-')}</td>
            <td>${esc(p.qty || '-')}</td>
            <td><span class="status-badge ${statusClass(p.status || 'Pending')}">${esc(p.status || 'Pending')}</span></td>
            <td><button type="button" class="ghost compact kpi-detail-open" data-kpi-open-equipment="${esc(e.unitNumber || e.tag || '')}">Buka Equipment</button></td>
          </tr>`;
        }).join('') : '<tr><td colspan="10"><div class="empty-state">Data tidak ditemukan.</div></td></tr>';
      } else {
        $('#kpiDetailTableHead').innerHTML = `<tr><th>No.</th><th>Nomor Unit</th><th>Equipment</th><th>Area</th><th>Criticality</th><th>Status</th><th>Total Titik Pelumasan</th><th>Aksi</th></tr>`;
        $('#kpiDetailTableBody').innerHTML = visible.length ? visible.map((e, i) => `<tr>
          <td>${start+i+1}</td>
          <td><b>${esc(e.unitNumber || e.tag || '-')}</b></td>
          <td><b>${esc(e.name || '-')}</b></td>
          <td>${esc(e.area || '-')}</td>
          <td>${esc(e.criticality || '-')}</td>
          <td><span class="status-badge ${statusClass(e.status || 'Normal')}">${esc(e.status || 'Normal')}</span></td>
          <td><b>${(e.points || []).length}</b> point</td>
          <td><button type="button" class="ghost compact kpi-detail-open" data-kpi-open-equipment="${esc(e.unitNumber || e.tag || '')}">Buka Equipment</button></td>
        </tr>`).join('') : '<tr><td colspan="8"><div class="empty-state">Data tidak ditemukan.</div></td></tr>';
      }

      const pager = $('#kpiDetailPagination');
      if (!rows.length) {
        pager.innerHTML = '<small>0 data</small>';
      } else {
        const maxButtons = 7;
        let first = Math.max(1, kpiDetailPage - 3), last = Math.min(totalPages, first + maxButtons - 1);
        first = Math.max(1, last - maxButtons + 1);
        const buttons = [];
        buttons.push(`<button type="button" data-kpi-page="${kpiDetailPage-1}" ${kpiDetailPage===1?'disabled':''}>‹</button>`);
        for (let p = first; p <= last; p++) buttons.push(`<button type="button" class="${p===kpiDetailPage?'active':''}" data-kpi-page="${p}">${p}</button>`);
        buttons.push(`<button type="button" data-kpi-page="${kpiDetailPage+1}" ${kpiDetailPage===totalPages?'disabled':''}>›</button>`);
        pager.innerHTML = `<small>Menampilkan ${start+1}–${Math.min(start+kpiDetailPageSize, rows.length)} dari ${rows.length} data</small><div class="pages">${buttons.join('')}</div>`;
      }
      translateTree($('#kpiDetail'));
    }

    function openKpiDetail(mode) {
      kpiDetailMode = kpiDetailConfig[mode] ? mode : 'equipment';
      kpiDetailPage = 1;
      if ($('#kpiDetailSearch')) $('#kpiDetailSearch').value = '';
      if ($('#kpiDetailAreaFilter')) $('#kpiDetailAreaFilter').value = '';
      goPage('kpiDetail');
    }

    $$('[data-kpi-detail]').forEach(btn => btn.addEventListener('click', () => openKpiDetail(btn.dataset.kpiDetail)));
    $('#kpiDetailSearch')?.addEventListener('input', () => { kpiDetailPage = 1; renderKpiDetail(); });
    $('#kpiDetailAreaFilter')?.addEventListener('change', () => { kpiDetailPage = 1; renderKpiDetail(); });
    $('#kpiDetailPagination')?.addEventListener('click', event => {
      const btn = event.target.closest('[data-kpi-page]');
      if (!btn || btn.disabled) return;
      kpiDetailPage = Number(btn.dataset.kpiPage) || 1;
      renderKpiDetail();
      window.scrollTo({top:0, behavior:'smooth'});
    });
    $('#kpiDetailTableBody')?.addEventListener('click', event => {
      const btn = event.target.closest('[data-kpi-open-equipment]');
      if (!btn) return;
      $('#equipmentSearch').value = btn.dataset.kpiOpenEquipment || '';
      $('#equipmentAreaFilter').value = '';
      equipmentPage = 1;
      goPage('equipment');
    });

    function statusClass(status) { return 'status-' + String(status).toLowerCase(); }

    // QR generator for equipment. Bundled PNGs keep the original equipment QR available offline.
    const bundledEquipmentQr = {};
    const equipmentQrDialog = $('#equipmentQrDialog');
    const equipmentQrLarge = $('#equipmentQrLarge');
    let activeQrEquipment = null;

    // Stable identity for every current equipment QR. Offline uses an internal SLM payload; hosted HTTPS uses a real deep-link.
    function equipmentOfflineQrPayload(equipment) { const unit=String(equipment?.unitNumber||equipment?.tag||'').trim(); return unit ? `SLM:EQUIPMENT:${unit}` : ''; }
    function equipmentQrPayload(equipment) { return equipmentOfflineQrPayload(equipment); }
    function equipmentUnitFromQrValue(value) {
      let raw=String(value||'').trim(); if(!raw) return '';
      try { const parsed=JSON.parse(raw); if(parsed&&typeof parsed==='object') raw=parsed.unitNumber||parsed.nomorUnit||parsed.nomor_unit||parsed.tag||parsed.equipment||parsed.asset||raw; } catch(_){}
      try { const url=new URL(raw); const h=url.hash.match(/(?:^#|&)equipment=([^&]+)/i); const q=url.searchParams.get('equipment')||url.searchParams.get('unitNumber')||url.searchParams.get('unit')||url.searchParams.get('asset'); const v=h?.[1]||q||''; if(v) return decodeURIComponent(v).trim(); } catch(_){}
      const slm=raw.match(/^SLM\s*[:|_-]?\s*EQUIPMENT\s*[:|=#_-]\s*(.+)$/i); if(slm) return slm[1].trim();
      const labeled=raw.match(/(?:nomor\s*unit|unit\s*number|equipment|asset|tag|kode)\s*[:=#-]\s*([a-z0-9._/-]+)/i); if(labeled) return labeled[1].trim();
      return raw.replace(/^SLM[:\s-]*/i,'').trim();
    }
    function handleEquipmentQrValue(value) {
      const unit=equipmentUnitFromQrValue(value); const equipment=state.equipment.find(e=>String(e.unitNumber).toLowerCase()===unit.toLowerCase()||String(e.tag).toLowerCase()===unit.toLowerCase());
      if(!equipment){ toast(`Equipment ${unit||'tidak dikenal'} tidak ditemukan.`); return false; }
      stopLiveQr(); if(scannerDialog?.open) scannerDialog.close(); goPage('equipment');
      setTimeout(()=>{ $('#equipmentSearch').value=equipment.unitNumber; renderEquipment(); const card=[...document.querySelectorAll('.equipment-card')].find(c=>c.dataset.tag===equipment.tag); if(card){card.classList.add('qr-match');card.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>card.classList.remove('qr-match'),2600);} openEquipmentDetail(equipment); toast(`Equipment ${equipment.unitNumber} ditemukan.`); },120);
      return true;
    }

    let liveQrStream = null;
    let liveQrTimer = null;
    let liveQrStartToken = 0;
    let liveQrDecoding = false;

    function stopMediaStream(stream) {
      try { stream?.getTracks?.().forEach(track => track.stop()); } catch (_) {}
    }

    function stopLiveQr() {
      liveQrStartToken += 1; // invalidate an in-flight permission/start request
      if (liveQrTimer) { cancelAnimationFrame(liveQrTimer); liveQrTimer = null; }
      liveQrDecoding = false;
      if (liveQrStream) { stopMediaStream(liveQrStream); liveQrStream = null; }
      const video = $('#qrLiveVideo');
      if (video) {
        try { video.pause(); } catch (_) {}
        try { video.srcObject = null; } catch (_) {}
      }
      const panel = $('#liveQrPanel');
      if (panel) { panel.hidden = true; panel.classList.remove('camera-error'); }
      const startBtn = $('#startLiveQrBtn');
      if (startBtn) { startBtn.disabled = false; startBtn.classList.remove('active'); }
    }

    async function waitForVideoReady(video, timeoutMs=3500) {
      if (video.readyState >= 2 && video.videoWidth > 0) return;
      await new Promise((resolve, reject) => {
        let done = false;
        const finish = (ok=true) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          video.removeEventListener('loadedmetadata', onReady);
          video.removeEventListener('canplay', onReady);
          video.removeEventListener('error', onError);
          ok ? resolve() : reject(new Error('Video preview gagal dimuat'));
        };
        const onReady = () => finish(true);
        const onError = () => finish(false);
        const timer = setTimeout(() => finish(video.readyState >= 2), timeoutMs);
        video.addEventListener('loadedmetadata', onReady, {once:true});
        video.addEventListener('canplay', onReady, {once:true});
        video.addEventListener('error', onError, {once:true});
      });
    }

    async function requestRearCameraStream() {
      // Satu kali request saja. Ini penting di HP agar browser tidak melakukan
      // beberapa siklus permission/constraint ketika tombol kamera ditekan.
      // facingMode "ideal" tetap memprioritaskan kamera belakang tanpa membuat
      // request gagal pada perangkat yang tidak melaporkan label kamera dengan baik.
      return navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
    }

    function describeCameraError(err) {
      const name = String(err?.name || '');
      if (!window.isSecureContext && location.protocol !== 'file:') {
        return 'Kamera live membutuhkan koneksi aman (HTTPS). Buka aplikasi melalui HTTPS agar scanner kamera dapat digunakan.';
      }
      if (name === 'NotAllowedError' || name === 'SecurityError') {
        return 'Akses kamera ditolak oleh browser. Aktifkan izin Kamera untuk situs ini di pengaturan browser; setelah diizinkan, scanner akan menyala langsung.';
      }
      if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
        return 'Kamera tidak ditemukan pada perangkat. Gunakan pilihan Galeri untuk membaca QR dari gambar.';
      }
      if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') {
        return 'Kamera sedang dipakai aplikasi lain atau belum siap. Tutup aplikasi kamera lain lalu coba lagi.';
      }
      if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
        return 'Kamera belakang tidak dapat dipilih otomatis pada browser ini. Coba buka aplikasi di Chrome melalui HTTPS.';
      }
      return 'Kamera belum dapat dimulai. Periksa izin kamera atau gunakan pilihan Galeri.';
    }

    async function startLiveQr() {
      const panel = $('#liveQrPanel');
      const status = $('#liveQrStatus');
      const video = $('#qrLiveVideo');
      const startBtn = $('#startLiveQrBtn');

      // Jika stream masih aktif, jangan meminta permission/getUserMedia lagi.
      // Cukup tampilkan kembali preview dan lanjutkan video.
      if (liveQrStream?.active && liveQrStream.getVideoTracks?.().some(track => track.readyState === 'live')) {
        if (panel) { panel.hidden = false; panel.classList.remove('camera-error'); }
        if (startBtn) { startBtn.disabled = false; startBtn.classList.add('active'); }
        $('#chooseQrGalleryBtn')?.classList.remove('active');
        try {
          if (video.srcObject !== liveQrStream) video.srcObject = liveQrStream;
          await video.play();
        } catch (_) {}
        if (status) status.textContent = 'Kamera aktif · scanner otomatis';
        setScanStatus('Scanner aktif. Arahkan QR Code ke kotak sampai terbaca otomatis.');
        return;
      }

      if (!navigator.mediaDevices?.getUserMedia) {
        if (panel) { panel.hidden = false; panel.classList.add('camera-error'); }
        if (status) status.textContent = 'Live camera tidak didukung pada mode browser ini.';
        setScanStatus('Live camera tidak tersedia. Gunakan Chrome melalui HTTPS atau pilih gambar QR dari Galeri.', 'error');
        return;
      }

      stopLiveQr();
      const myToken = ++liveQrStartToken;
      if (panel) { panel.hidden = false; panel.classList.remove('camera-error'); }
      if (status) status.textContent = 'Menyalakan kamera belakang...';
      if (startBtn) { startBtn.disabled = true; startBtn.classList.add('active'); }
      $('#chooseQrGalleryBtn')?.classList.remove('active');
      setScanStatus('Menyalakan kamera QR otomatis…', 'loading');

      try {
        const stream = await requestRearCameraStream();
        if (myToken !== liveQrStartToken) { stopMediaStream(stream); return; }
        liveQrStream = stream;

        video.muted = true;
        video.autoplay = true;
        video.setAttribute('playsinline', '');
        video.setAttribute('webkit-playsinline', '');
        video.srcObject = stream;
        await waitForVideoReady(video);
        if (myToken !== liveQrStartToken) return;
        await video.play();

        if (startBtn) startBtn.disabled = false;
        const track = stream.getVideoTracks?.()[0];
        try {
          const capabilities = track?.getCapabilities?.() || {};
          const advanced = {};
          if (Array.isArray(capabilities.focusMode) && capabilities.focusMode.includes('continuous')) {
            advanced.focusMode = 'continuous';
          }
          if (Object.keys(advanced).length) await track.applyConstraints({advanced:[advanced]});
        } catch (_) {}
        const settings = track?.getSettings?.() || {};
        const cameraLabel = track?.label ? ` · ${track.label}` : '';
        if (status) status.textContent = `Kamera aktif${cameraLabel}`;
        setScanStatus('Scanner aktif. Posisikan QR Code di dalam kotak hingga terbaca otomatis.');

        const canvas = $('#qrScannerCanvas');
        const ctx = canvas.getContext('2d', {willReadFrequently:true});
        let lastScanAt = 0;
        let scanCount = 0;

        const scan = async (timestamp=0) => {
          if (!liveQrStream || myToken !== liveQrStartToken) return;
          if (video.readyState < 2 || liveQrDecoding || timestamp - lastScanAt < 180) {
            liveQrTimer = requestAnimationFrame(scan);
            return;
          }
          lastScanAt = timestamp;
          const vw = video.videoWidth, vh = video.videoHeight;
          if (!vw || !vh) { liveQrTimer = requestAnimationFrame(scan); return; }

          // Prioritaskan area tengah sesuai frame scanner agar pembacaan QR lebih cepat di HP.
          const cropSide = Math.max(1, Math.round(Math.min(vw, vh) * 0.72));
          const sx = Math.max(0, Math.round((vw - cropSide) / 2));
          const sy = Math.max(0, Math.round((vh - cropSide) / 2));
          const scanSize = Math.min(820, cropSide);
          canvas.width = scanSize;
          canvas.height = scanSize;
          ctx.drawImage(video, sx, sy, cropSide, cropSide, 0, 0, scanSize, scanSize);

          liveQrDecoding = true;
          try {
            let raw = await decodeQrFromCanvas(canvas);

            // Sesekali scan seluruh frame untuk QR yang belum tepat di tengah kotak.
            scanCount += 1;
            if (!raw && scanCount % 4 === 0) {
              const maxScanWidth = 900;
              const scale = Math.min(1, maxScanWidth / vw);
              const w = Math.max(1, Math.round(vw * scale));
              const h = Math.max(1, Math.round(vh * scale));
              canvas.width = w;
              canvas.height = h;
              ctx.drawImage(video, 0, 0, w, h);
              raw = await decodeQrFromCanvas(canvas);
            }

            if (raw && liveQrStream && myToken === liveQrStartToken) {
              if (status) status.textContent = `QR terbaca: ${raw}`;
              if (applyIdentification(raw, 'kamera QR otomatis')) {
                stopLiveQr();
                return;
              }
            }
          } catch (_) {
            // Satu frame gagal tidak boleh menghentikan live scanner.
          } finally {
            liveQrDecoding = false;
          }
          if (liveQrStream && myToken === liveQrStartToken) liveQrTimer = requestAnimationFrame(scan);
        };
        liveQrTimer = requestAnimationFrame(scan);
      } catch (err) {
        if (myToken !== liveQrStartToken) return;
        if (startBtn) { startBtn.disabled = false; startBtn.classList.remove('active'); }
        stopMediaStream(liveQrStream);
        liveQrStream = null;
        try { video.pause(); video.srcObject = null; } catch (_) {}
        if (panel) { panel.hidden = false; panel.classList.add('camera-error'); }
        const message = describeCameraError(err);
        if (status) status.textContent = message;
        setScanStatus(message, 'error');
      }
    }

    function buildEquipmentQr(container,equipment,size=96,allowRemote=true){
      if(!container||!equipment)return; const payload=equipmentQrPayload(equipment); const offlinePayload=equipmentOfflineQrPayload(equipment); container.innerHTML=''; if(!payload){container.textContent='QR tidak tersedia';return;}
      if(typeof window.QRCode==='function'){try{new window.QRCode(container,{text:payload,width:size,height:size,colorDark:'#000000',colorLight:'#ffffff',correctLevel:window.QRCode.CorrectLevel.M});return;}catch(_){}}
      const bundled=bundledEquipmentQr[offlinePayload]; if(bundled){const img=document.createElement('img');img.alt=`QR Code ${equipment.unitNumber||equipment.tag}`;img.loading='lazy';img.src=bundled;container.appendChild(img);return;}
      container.textContent='QR tidak tersedia';
    }

    function renderEquipmentQrCodes() {
      if (equipmentQrObserver) equipmentQrObserver.disconnect();
      const mounts = $$('[data-equipment-qr]');
      const build = mount => {
        if (mount.dataset.qrReady === '1') return;
        const equipment = state.equipmentByUnit?.get(String(mount.dataset.equipmentQr)) || state.equipment.find(item => String(item.unitNumber) === String(mount.dataset.equipmentQr));
        if (!equipment) return;
        mount.dataset.qrReady = '1';
        mount.classList.remove('is-lazy');
        buildEquipmentQr(mount, equipment, 80, false);
      };
      if ('IntersectionObserver' in window) {
        equipmentQrObserver = new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (entry.isIntersecting) { build(entry.target); equipmentQrObserver.unobserve(entry.target); }
          });
        }, {rootMargin:'120px'});
        mounts.forEach(mount => { mount.classList.add('is-lazy'); mount.textContent = 'QR'; equipmentQrObserver.observe(mount); });
      } else {
        mounts.forEach(build);
      }
    }

    function qrGraphicSource(container) {
      const canvas = container?.querySelector('canvas');
      if (canvas) {
        try { return canvas.toDataURL('image/png'); } catch (_) {}
      }
      return container?.querySelector('img')?.src || '';
    }

    function openEquipmentQr(unitNumber) {
      const equipment = state.equipment.find(item => String(item.unitNumber) === String(unitNumber));
      if (!equipment) { toast('Equipment tidak ditemukan.'); return; }
      activeQrEquipment = equipment;
      $('#equipmentQrName').textContent = equipment.name || 'Equipment';
      $('#equipmentQrUnit').textContent = equipment.unitNumber || equipment.tag || '-';
      $('#equipmentQrTag').textContent = `Tag: ${equipment.tag || '-'}`;
      $('#equipmentQrArea').textContent = `Lokasi: ${equipment.area || '-'}`;
      $('#equipmentQrStatus').textContent = equipmentQrPayload(equipment).includes('://') ? 'QR deep-link aktif: scan dengan kamera/Google Lens untuk membuka aplikasi langsung ke Detail Equipment.' : 'QR offline aktif: scan melalui menu Scan QR Equipment untuk membuka Detail Equipment unit ini.';
      buildEquipmentQr(equipmentQrLarge, equipment, 230);
      equipmentQrDialog.showModal();
    }

    function safeQrFilename(value) {
      return String(value || 'equipment').replace(/[^a-z0-9._-]+/gi, '_');
    }

    function downloadActiveEquipmentQr() {
      if (!activeQrEquipment) return;
      const src = qrGraphicSource(equipmentQrLarge);
      if (!src) { toast('QR Code belum siap.'); return; }
      const a = document.createElement('a');
      a.href = src;
      a.download = `QR_${safeQrFilename(activeQrEquipment.unitNumber || activeQrEquipment.tag)}.png`;
      if (!src.startsWith('data:') && !src.startsWith('blob:')) a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }

    function printActiveEquipmentQr() {
      if (!activeQrEquipment) return;
      const src = qrGraphicSource(equipmentQrLarge);
      if (!src) { toast('QR Code belum siap.'); return; }
      const e = activeQrEquipment;
      if (window.QIEAndroid) { QIEAndroid.printLabel(src, e.unitNumber || e.tag, e.name, e.area || ''); return; }
      const win = window.open('', '_blank', 'width=520,height=680');
      if (!win) { toast('Pop-up diblokir browser. Izinkan pop-up untuk mencetak label.'); return; }
      const escapePrint = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
      win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>QR ${escapePrint(e.unitNumber || e.tag)}</title><style>
        @page { size: 70mm 95mm; margin: 4mm; }
        * { box-sizing:border-box; } body { margin:0; font-family:Arial,sans-serif; color:#111; }
        .label { width:62mm; min-height:86mm; margin:auto; border:1.2px solid #111; border-radius:3mm; padding:4mm; text-align:center; }
        .brand { font-weight:800; font-size:10pt; margin-bottom:2mm; } img { width:45mm; height:45mm; object-fit:contain; }
        h1 { font-size:10pt; margin:2mm 0 1mm; } .unit { font-size:12pt; font-weight:900; letter-spacing:.5px; margin:1mm 0; }
        p { font-size:8pt; margin:1mm 0; } .scan { margin-top:2mm; font-size:7pt; }
      </style></head><body><div class="label"><div class="brand">Quick Identify Equipment</div>
        <img src="${src}" alt="QR Code"><h1>${escapePrint(e.name)}</h1>
        <div class="unit">${escapePrint(e.unitNumber || e.tag || '-')}</div>
        <p>Tag: ${escapePrint(e.tag || '-')}</p><p>${escapePrint(e.area || '-')}</p>
        <p class="scan">Scan dengan Google Lens atau kamera HP untuk membuka/identifikasi equipment</p></div>
        <script>window.onload=()=>{setTimeout(()=>window.print(),150)};<\/script></body></html>`);
      win.document.close();
    }
    const equipmentDetailDialog=$('#equipmentDetailDialog'); let activeDetailEquipment=null;
    function displayEquipmentValue(value){const text=String(value??'').trim();return text&&text!=='-'?text:'Belum diinput';}
    function openEquipmentDetail(equipment){
      if(!equipment||!equipmentDetailDialog)return; activeDetailEquipment=equipment; $('#equipmentDetailUnit').textContent=equipment.unitNumber||equipment.tag||'-'; $('#equipmentDetailName').textContent=equipment.name||'Equipment'; $('#equipmentDetailArea').textContent=`${equipment.area||'-'} · Tag ${equipment.tag||'-'}`;
            const fields=[['Tahun Manufaktur',equipment.manufactureYear],['Power Source',equipment.powerSource],['Status Operasional',equipment.operationalStatus],['Criticality',equipment.criticality],['Oil Type',equipment.oil],['Oil Capacity',equipment.oilCapacity],['Grease Type',equipment.grease],['Grease Capacity',equipment.greaseCapacity],['Total Lubrication Point',`${(equipment.points||[]).length} point`]];
      $('#equipmentDetailGrid').innerHTML=fields.map(([l,v])=>`<div class="equipment-detail-item"><span>${esc(l)}</span><strong>${esc(displayEquipmentValue(v))}</strong></div>`).join('');
      const points=equipment.points||[]; $('#equipmentDetailPoints').innerHTML=points.length?points.map((p,i)=>`<div class="equipment-detail-point"><strong>${i+1}. ${esc(p.name||'Lubrication Point')}</strong><small>${esc(p.lubricant||'Lubricant belum diinput')} · ${esc(p.lubricantType||'-')} · Interval ${esc(p.interval||'-')} · Qty ${esc(p.qty||'-')} · Status ${esc(p.status||'Pending')}</small></div>`).join(''):'<div class="empty-state">Belum ada lubrication point terdaftar untuk unit ini.</div>';
      translateTree(equipmentDetailDialog); if(!equipmentDetailDialog.open)equipmentDetailDialog.showModal();
    }

    function renderEquipment() {
      const q = $('#equipmentSearch').value.trim().toLowerCase();
      const area = $('#equipmentAreaFilter').value;
      const filtered = state.equipment.filter(e =>
        (!q || equipmentSearchText(e).includes(q)) &&
        (!area || e.area === area)
      );

      const totalPages = Math.max(1, Math.ceil(filtered.length / equipmentPageSize));
      equipmentPage = Math.min(Math.max(1, equipmentPage), totalPages);
      const startIndex = (equipmentPage - 1) * equipmentPageSize;
      const list = filtered.slice(startIndex, startIndex + equipmentPageSize);
      const container = $('#equipmentList');

      container.innerHTML = list.length ? list.map(e => {
        const greasePoints = e.points || [];
        return `
        <article class="equipment-card" data-tag="${esc(e.tag)}">
          <div class="equipment-card-head"><span class="equipment-tag">${esc(e.tag)}</span></div>
          <div class="equipment-identity">
            <span class="equipment-unit-number">Nomor Unit: ${esc(e.unitNumber)}</span>
            <h3>${esc(e.name)}</h3>
            <div class="equipment-area">${esc(e.area)}</div>

          </div>
          <div class="meta-grid">
            <div class="meta-row"><span>Oil Type</span><b>${shownTechValue(e.oil)}</b></div>
            <div class="meta-row"><span>Oil Capacity</span><b>${shownTechValue(e.oilCapacity)}</b></div>
            <div class="meta-row"><span>Grease Type</span><b>${shownTechValue(e.grease)}</b></div>
            <div class="meta-row"><span>Kapasitas grease manual</span><b>${shownTechValue(e.greaseCapacity)}</b></div>
            <div class="meta-row"><span>Titik grease</span><b>${greasePointsFor(e).length} point</b></div>
            <div class="meta-row"><span>Total Lubrication Point</span><b>${(e.points || []).length} point</b></div>
          </div>
          <div class="technical-section">
            <h4>Pelumasan per Komponen</h4>
            <p>Kapasitas referensi PDF, bukan otomatis dosis top-up. Baca catatan tiap komponen.</p>
            <div class="point-list">${greasePoints.length ? greasePoints.map((p,i) => `<div class="point-chip"><b>${i+1}. ${esc(p.name)}</b><br>${esc(p.lubricant)} · ${esc(p.lubricantType || '')} · ${esc(p.interval)}<br><span class="point-qty">Kapasitas PDF: ${esc(p.qty || 'Belum diinput')}</span><br><small>${esc(p.notes || '')}</small><br><small>Sumber PDF hlm. ${esc(p.sourcePage || '-')}</small>${p.qualityFlags?.length ? '<br><small class=source-warning>Perlu verifikasi: '+esc(p.qualityFlags.join('; '))+'</small>' : ''}</div>`).join('') : '<div class="point-chip">Belum ada greasing point terdaftar.</div>'}</div>
          </div>
          <div class="equipment-qr-block">
            <div class="equipment-qr-mini" data-equipment-qr="${esc(e.unitNumber)}" aria-label="QR Code ${esc(e.unitNumber)}"></div>
            <div class="equipment-qr-copy">
              <strong>QR Equipment</strong>
              <small>QR unik unit ini. Baca QR secara offline melalui menu Scan QR.</small>
              <button type="button" class="ghost compact qr-code-action" data-show-equipment-qr="${esc(e.unitNumber)}">▣ View Equipment QR</button>
            </div>
          </div>
          <div class="card-actions equipment-card-actions">
            <button type="button" class="ghost edit-icon" data-edit-equipment="${esc(e.id)}" aria-label="Edit technical data ${esc(e.unitNumber)}">✏ Edit Technical Data</button>
            <button type="button" class="danger delete-icon" ${initialState.equipment.some(ref=>ref.id===e.id)?'hidden':''} data-delete-equipment="${esc(e.id)}" aria-label="Hapus equipment ${esc(e.unitNumber)}">🗑 Delete</button>
          </div>
        </article>`;
      }).join('') : '<div class="empty-state" style="grid-column:1/-1">Equipment tidak ditemukan. Coba nomor unit, nama alat, lubricant, atau area lain.</div>';

      const pager = $('#equipmentPagination');
      if (!filtered.length) {
        pager.hidden = true;
        pager.innerHTML = '';
      } else if (totalPages > 1) {
        const pages = [];
        const from = Math.max(1, equipmentPage - 2);
        const to = Math.min(totalPages, from + 4);
        for (let p = from; p <= to; p++) pages.push(`<button type="button" class="${p === equipmentPage ? 'active' : ''}" data-equipment-page="${p}">${p}</button>`);
        pager.hidden = false;
        pager.innerHTML = `<span class="equipment-result-count">Menampilkan ${startIndex + 1}-${Math.min(startIndex + equipmentPageSize, filtered.length)} dari ${filtered.length} equipment</span><div class="pages"><button type="button" data-equipment-page="${equipmentPage-1}" ${equipmentPage===1?'disabled':''}>‹</button>${pages.join('')}<button type="button" data-equipment-page="${equipmentPage+1}" ${equipmentPage===totalPages?'disabled':''}>›</button></div>`;
      } else {
        pager.hidden = false;
        pager.innerHTML = `<span class="equipment-result-count">${filtered.length} equipment</span>`;
      }
      renderEquipmentQrCodes();
      translateTree(container); translateTree(pager);
    }

    function refreshAreaFilter() {
      const current = $('#equipmentAreaFilter').value;
      const areas = [...new Set(state.equipment.map(e => e.area))].sort();
      $('#equipmentAreaFilter').innerHTML = '<option value="">Semua Area</option>' + areas.map(a => `<option>${esc(a)}</option>`).join('');
      if (areas.includes(current)) $('#equipmentAreaFilter').value = current;
      translateTree($('#equipmentAreaFilter'));
    }
    function scheduleEquipmentRender(resetPage=true) {
      if (resetPage) equipmentPage = 1;
      clearTimeout(equipmentSearchTimer);
      equipmentSearchTimer = setTimeout(() => requestAnimationFrame(renderEquipment), 90);
    }
    $('#equipmentSearch').addEventListener('input', () => scheduleEquipmentRender(true));
    $('#equipmentSearch').addEventListener('change', () => scheduleEquipmentRender(true));
    $('#equipmentAreaFilter').addEventListener('change', () => scheduleEquipmentRender(true));
    $('#equipmentPagination').addEventListener('click', event => {
      const btn = event.target.closest('[data-equipment-page]');
      if (!btn || btn.disabled) return;
      equipmentPage = Number(btn.dataset.equipmentPage) || 1;
      requestAnimationFrame(renderEquipment);
      window.scrollTo({top:0, behavior:'smooth'});
    });
    $('#equipmentList').addEventListener('click', event => {
      const detail = event.target.closest('[data-view-equipment-detail]');
      if (detail) { const equipment = state.equipment.find(item => String(item.unitNumber) === String(detail.dataset.viewEquipmentDetail)); if (equipment) openEquipmentDetail(equipment); return; }
      const qr = event.target.closest('[data-show-equipment-qr]');
      if (qr) { openEquipmentQr(qr.dataset.showEquipmentQr); return; }
      const edit = event.target.closest('[data-edit-equipment]');
      if (edit) { openEquipmentDialog(edit.dataset.editEquipment); return; }
      const del = event.target.closest('[data-delete-equipment]');
      if (del) deleteEquipment(del.dataset.deleteEquipment);
    });

    let lubricantSearchTimer = null;

    function lubricantSearchText(l) {
      return [l.name, l.type, l.brand, l.grade, l.application].map(v => String(v || '').toLowerCase()).join(' ');
    }

    function getFilteredLubricants() {
      const query = String($('#lubricantSearch')?.value || '').trim().toLowerCase();
      if (!query) return state.lubricants.slice();
      const terms = query.split(/\s+/).filter(Boolean);
      return state.lubricants.filter(l => {
        const haystack = lubricantSearchText(l);
        return terms.every(term => haystack.includes(term));
      });
    }

    function renderLubricantSuggestions() {
      const input = $('#lubricantSearch');
      const box = $('#lubricantSuggestions');
      if (!input || !box) return;
      const query = input.value.trim().toLowerCase();
      if (!query) { box.classList.remove('show'); box.innerHTML = ''; return; }

      const seen = new Set();
      const queryTerms = query.split(/\s+/).filter(Boolean);
      const matches = state.lubricants
        .filter(l => {
          const haystack = lubricantSearchText(l);
          return queryTerms.every(term => haystack.includes(term));
        })
        .filter(l => {
          const key = `${String(l.name || '').toLowerCase()}|${String(l.brand || '').toLowerCase()}|${String(l.type || '').toLowerCase()}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        })
        .sort((a,b) => {
          const an = String(a.name || '').toLowerCase(), bn = String(b.name || '').toLowerCase();
          const aStarts = an.startsWith(query) ? 0 : 1, bStarts = bn.startsWith(query) ? 0 : 1;
          return aStarts - bStarts || an.localeCompare(bn);
        })
        .slice(0, 8);

      if (!matches.length) {
        box.innerHTML = `<div class="empty-state" style="padding:14px">Tidak ada sugesti untuk <b>${esc(input.value.trim())}</b>.</div>`;
        box.classList.add('show');
        translateTree(box);
        return;
      }

      box.innerHTML = matches.map(l => {
        const low = Number(l.stock) < Number(l.minimum);
        return `<button type="button" class="lubricant-suggestion" role="option" data-lubricant-suggestion="${esc(l.name)}">
          <span><strong>${esc(l.name)}</strong><small>${esc(l.type)}${l.brand ? ` · ${esc(l.brand)}` : ''}${l.grade ? ` · ${esc(l.grade)}` : ''}</small></span>
          <span class="lubricant-suggestion-stock ${low ? 'low' : 'ok'}">Stock ${esc(l.stock)}<small>Min ${esc(l.minimum)}</small></span>
        </button>`;
      }).join('');
      box.classList.add('show');
      translateTree(box);
    }

    function scheduleLubricantSearch() {
      clearTimeout(lubricantSearchTimer);
      lubricantSearchTimer = setTimeout(() => {
        renderLubricants();
        renderLubricantSuggestions();
      }, 55);
    }

    function focusFirstLubricantResult() {
      const first = $('#lubricantList .lubricant-card');
      if (first) first.scrollIntoView({behavior:'smooth', block:'center'});
    }

    function renderLubricants() {
      const all = Array.isArray(state.lubricants) ? state.lubricants : [];
      const list = getFilteredLubricants();
      const query = String($('#lubricantSearch')?.value || '').trim();
      const count = $('#lubricantResultCount');
      const hint = $('#lubricantSearchHint');
      if (count) count.textContent = `${list.length} dari ${all.length} item`;
      if (hint) hint.textContent = query ? `Hasil pencarian untuk “${query}”. Stock dan minimum ditampilkan pada setiap kartu.` : 'Ketik huruf untuk mendapatkan sugesti pencarian secara langsung.';

      $('#lubricantList').innerHTML = list.length ? list.map(l => {
        const stock = Number(l.stock) || 0;
        const minimum = Number(l.minimum) || 0;
        const low = stock < minimum;
        const pct = Math.min(100, Math.round(stock / Math.max(minimum*2,1) * 100));
        return `<article class="lubricant-card ${low ? 'low-stock':''} search-match" data-lubricant-card-id="${esc(l.id)}"><span class="equipment-tag">${esc(l.type)}</span><h3>${esc(l.name)}</h3><div class="equipment-area">${esc(l.brand || '')}${l.brand ? ' · ' : ''}${esc(l.grade)} · ${esc(l.application)}</div><span class="stock-status ${low ? 'low':'ok'}">${low ? 'Stock di bawah minimum' : 'Stock tersedia'}</span><div class="meta-grid"><div class="meta-row"><span>Stock Saat Ini</span><b>${esc(l.stock)}</b></div><div class="meta-row"><span>Minimum Stock</span><b>${esc(l.minimum)}</b></div><div class="meta-row"><span>Selisih</span><b>${stock-minimum >= 0 ? '+' : ''}${stock-minimum}</b></div></div><div class="stock-bar" title="Perbandingan stock saat ini terhadap minimum"><span style="width:${pct}%"></span></div><div class="card-actions"><button type="button" class="ghost edit-icon" data-edit-lubricant="${esc(l.id)}">✏ Edit</button><button type="button" class="danger delete-icon" data-delete-lubricant="${esc(l.id)}">🗑 Hapus</button></div></article>`;
      }).join('') : '<div class="empty-state" style="grid-column:1/-1">Tidak ada grease/oil yang cocok. Coba nama produk, brand, grade, atau application lain.</div>';
      $$('[data-edit-lubricant]').forEach(btn => btn.addEventListener('click', () => openLubricantDialog(btn.dataset.editLubricant)));
      $$('[data-delete-lubricant]').forEach(btn => btn.addEventListener('click', () => deleteLubricant(btn.dataset.deleteLubricant)));
      translateTree($('#lubricants'));
    }

    $('#lubricantSearch').addEventListener('input', scheduleLubricantSearch);
    $('#lubricantSearch').addEventListener('focus', renderLubricantSuggestions);
    $('#lubricantSearch').addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        renderLubricants();
        $('#lubricantSuggestions').classList.remove('show');
        focusFirstLubricantResult();
      } else if (event.key === 'Escape') {
        $('#lubricantSuggestions').classList.remove('show');
      }
    });
    $('#lubricantSearchBtn').addEventListener('click', () => {
      renderLubricants();
      $('#lubricantSuggestions').classList.remove('show');
      focusFirstLubricantResult();
    });
    $('#lubricantSearchResetBtn').addEventListener('click', () => {
      $('#lubricantSearch').value = '';
      $('#lubricantSuggestions').classList.remove('show');
      renderLubricants();
      $('#lubricantSearch').focus();
    });
    $('#lubricantSuggestions').addEventListener('click', event => {
      const option = event.target.closest('[data-lubricant-suggestion]');
      if (!option) return;
      $('#lubricantSearch').value = option.dataset.lubricantSuggestion || '';
      $('#lubricantSuggestions').classList.remove('show');
      renderLubricants();
      focusFirstLubricantResult();
    });
    document.addEventListener('click', event => {
      if (!event.target.closest('#lubricantSearchPanel')) $('#lubricantSuggestions')?.classList.remove('show');
    });

    function renderRoute() {
      refreshLubricationPointAreaFilter();
      const all = lubricationPoints();
      const list = filteredLubricationPoints();
      const verified = x => x.status === 'Done' ? Boolean(x.evidence?.before && x.evidence?.after) : (x.status === 'Skipped' ? Boolean(x.evidence?.before) : false);
      const done = list.filter(verified).length;
      const pct = list.length ? Math.round(done/list.length*100) : 0;
      const selectedArea = String($('#lubricationPointAreaFilter')?.value || '').trim();
      $('#routeEstimate').textContent = `${list.length*8} menit`;
      $('#routeProgressText').textContent = `${done}/${list.length} tampil · ${all.length} total`;
      $('#routeProgressBar').style.width = `${pct}%`;
      $('#routeAreaSummary').textContent = selectedArea || 'Semua Area';
      $('#routeSteps').innerHTML = list.length ? list.map((x,i) => {
        const beforeOk = Boolean(x.evidence?.before);
        const afterOk = Boolean(x.evidence?.after);
        const temperatureOk = Boolean(x.evidence?.temperature);
        const completed = verified(x);
        return `<article class="route-step ${completed ? 'completed' : ''}">
          <div class="step-number">${completed ? '✓' : '●'}</div>
          <div>
            <h4>${esc(x.equipment.tag)} · ${esc(x.name)}</h4>
            <p>${esc(x.equipment.name)} · ${esc(x.equipment.area)} · ${esc(x.lubricant)} · Target ${esc(x.qty)} · Interval ${esc(x.interval)}</p>
            <div class="route-tech-meta">
              <span class="route-tech-pill">Bebas dipilih</span>
              <span class="route-tech-pill">Grease: ${esc(x.lubricant || 'N/A')}</span>
              <span class="route-tech-pill">Qty: ${esc(x.qty || 'N/A')}</span>
            </div>
            <div class="route-photo-state">
              <span class="photo-state ${temperatureOk?'ok':'missing'}">TEMP ${temperatureOk?'✓':'optional'}</span>
              <span class="photo-state ${beforeOk?'ok':'missing'}">BEFORE ${beforeOk?'✓':'required'}</span>
              <span class="photo-state ${afterOk?'ok':'missing'}">AFTER ${afterOk?'✓':'required'}</span>
              <span class="status-badge ${statusClass(x.status)}">${esc(x.status)}</span>
            </div>
          </div>
          <button class="${completed?'ghost':'primary'}" data-point="${esc(x.id)}">${completed ? '✓ Review Evidence' : '📋 Open Point'}</button>
        </article>`;
      }).join('') : '<div class="empty-state">Tidak ada greasing point yang sesuai dengan filter.</div>';
      $$('[data-point]').forEach(btn => btn.addEventListener('click', () => openPointDialog(btn.dataset.point)));
      translateTree($('#route'));
    }

    let lubricationDatabasePage = 1;
    function renderLubricationDatabase(resetPage=false) {
      const data = Array.isArray(state.lubricationDatabase) ? state.lubricationDatabase : [];
      if (resetPage) lubricationDatabasePage = 1;
      const q = String($('#databaseSearch')?.value || '').trim().toLowerCase();
      const type = String($('#databaseTypeFilter')?.value || '').trim().toUpperCase();
      const area = String($('#databaseAreaFilter')?.value || '').trim();
      const pageSize = Number($('#databasePageSize')?.value || 50);
      const filtered = data.filter(r => {
        const hay = [r.area,r.equipment,r.description,r.component,r.modifier,r.type,r.brand,r.name,r.oilLifeTarget,r.topUpFactor,r.capacity,r.units,r.workingHrsYear,r.rateHr,r.consumptionMtH,r.notes].join(' ').toLowerCase();
        return (!q || hay.includes(q)) && (!type || String(r.type || '').toUpperCase() === type) && (!area || r.area === area);
      });
      const pages = Math.max(1, Math.ceil(filtered.length/pageSize));
      lubricationDatabasePage = Math.min(lubricationDatabasePage, pages);
      const start = (lubricationDatabasePage-1)*pageSize;
      const visible = filtered.slice(start,start+pageSize);
      $('#dbEquipmentCount').textContent = new Set(data.map(r=>r.equipment)).size;
      $('#dbRecordCount').textContent = data.length;
      $('#dbGreaseCount').textContent = data.filter(r=>r.type==='GREASE').length;
      $('#dbOilCount').textContent = data.filter(r=>r.type==='OIL').length;
      $('#lubricationDatabaseBody').innerHTML = visible.length ? visible.map((r,i)=>`<tr>
        <td>${start+i+1}</td><td>${esc(r.area)}</td><td><b>${esc(r.equipment)}</b></td><td>${esc(r.description)}</td><td>${esc([r.component,r.modifier].filter(Boolean).join(' · ') || '-')}</td>
        <td><span class="database-type ${String(r.type||'').toLowerCase()}">${esc(r.type || 'Not specified')}</span></td><td>${esc(r.brand || '-')}</td><td><b>${esc(r.name || '-')}</b></td>
        <td>${esc(r.oilLifeTarget || '-')}</td><td>${esc(r.topUpFactor || '-')}</td><td>${esc(r.capacity || '-')}</td><td>${esc(r.units || '-')}</td>
        <td>${esc(r.workingHrsYear || '-')}</td><td>${esc(r.rateHr || '-')}</td><td>${esc(r.consumptionMtH || '-')}</td><td>${esc(r.notes || '-')}<br><small>PDF hlm. ${esc(r.sourcePage)}</small>${r.qualityFlags?.length ? '<br><small class=source-warning>'+esc(r.qualityFlags.join('; '))+'</small>' : ''}</td>
      </tr>`).join('') : '<tr><td colspan="16"><div class="empty-state">Data lubricant tidak ditemukan.</div></td></tr>';
      const pageButtons=[];
      const maxButtons=7;
      let first=Math.max(1,lubricationDatabasePage-3), last=Math.min(pages,first+maxButtons-1); first=Math.max(1,last-maxButtons+1);
      for(let p=first;p<=last;p++) pageButtons.push(`<button type="button" class="${p===lubricationDatabasePage?'active':''}" data-db-page="${p}">${p}</button>`);
      $('#lubricationDatabasePagination').innerHTML = `<small>Menampilkan ${filtered.length ? start+1 : 0}–${Math.min(start+pageSize,filtered.length)} dari ${filtered.length} record</small><div class="pages">${pageButtons.join('')}</div>`;
      $$('[data-db-page]').forEach(btn=>btn.addEventListener('click',()=>{lubricationDatabasePage=Number(btn.dataset.dbPage);renderLubricationDatabase(false);window.scrollTo({top:0,behavior:'smooth'});}));
      translateTree($('#lubricationDatabasePagination'));
      if (!visible.length) translateTree($('#lubricationDatabaseBody'));
    }

    let historySearchTimer = null;

    function historySearchText(h) {
      return [h.date, h.equipment, h.point, h.lubricant, h.qty, h.status, h.technician, h.condition, h.reason]
        .map(v => String(v || '').toLowerCase()).join(' ');
    }

    function getFilteredHistoryWithIndex() {
      const query = String($('#historySearch')?.value || '').trim().toLowerCase();
      const rows = state.history.map((h, index) => ({h, index}));
      if (!query) return rows;
      const terms = query.split(/\s+/).filter(Boolean);
      return rows.filter(({h}) => {
        const haystack = historySearchText(h);
        return terms.every(term => haystack.includes(term));
      });
    }

    function renderHistorySuggestions() {
      const input = $('#historySearch');
      const box = $('#historySuggestions');
      if (!input || !box) return;
      const query = input.value.trim().toLowerCase();
      if (!query) { box.classList.remove('show'); box.innerHTML = ''; return; }

      const terms = query.split(/\s+/).filter(Boolean);
      const seen = new Set();
      const matches = state.history
        .filter(h => terms.every(term => historySearchText(h).includes(term)))
        .filter(h => {
          const key = [h.date,h.equipment,h.point,h.lubricant,h.status,h.technician].map(v => String(v || '').toLowerCase()).join('|');
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        })
        .sort((a,b) => {
          const ae = String(a.equipment || '').toLowerCase();
          const be = String(b.equipment || '').toLowerCase();
          const aStarts = ae.startsWith(query) ? 0 : 1;
          const bStarts = be.startsWith(query) ? 0 : 1;
          return aStarts - bStarts || String(b.date || '').localeCompare(String(a.date || ''));
        })
        .slice(0, 8);

      if (!matches.length) {
        box.innerHTML = `<div class="empty-state" style="padding:14px">Tidak ada sugesti history untuk <b>${esc(input.value.trim())}</b>.</div>`;
        box.classList.add('show');
        translateTree(box);
        return;
      }

      box.innerHTML = matches.map(h => {
        const value = [h.equipment, h.point].filter(Boolean).join(' ');
        return `<button type="button" class="lubricant-suggestion" role="option" data-history-suggestion="${esc(value)}">
          <span><strong>${esc(h.equipment || '-')} · ${esc(h.point || '-')}</strong><small>${esc(h.date || '-')} · ${esc(h.lubricant || '-')} · ${esc(h.technician || '-')}</small></span>
          <span class="status-badge ${statusClass(h.status)}">${esc(h.status || '-')}</span>
        </button>`;
      }).join('');
      box.classList.add('show');
      translateTree(box);
    }

    function scheduleHistorySearch() {
      clearTimeout(historySearchTimer);
      historySearchTimer = setTimeout(() => {
        renderHistory();
        renderHistorySuggestions();
      }, 55);
    }

    function focusFirstHistoryResult() {
      const first = $('#historyTableBody tr');
      if (first) first.scrollIntoView({behavior:'smooth', block:'center'});
    }

    function renderHistory() {
      const all = Array.isArray(state.history) ? state.history : [];
      const filtered = getFilteredHistoryWithIndex();
      const query = String($('#historySearch')?.value || '').trim();
      const count = $('#historyResultCount');
      const hint = $('#historySearchHint');
      if (count) count.textContent = `${filtered.length} dari ${all.length} record`;
      if (hint) hint.textContent = query
        ? `Hasil pencarian untuk “${query}”. Anda tetap dapat membuka foto, edit, atau menghapus record hasil pencarian.`
        : 'Ketik huruf untuk memfilter history dan mendapatkan sugesti secara langsung.';

      $('#historyTableBody').innerHTML = filtered.length ? filtered.map(({h,index}) => `<tr>
        <td>${esc(h.date)}</td><td>${esc(h.equipment)}</td><td>${esc(h.point)}</td><td>${esc(h.lubricant)}</td><td>${esc(h.qty)}</td>
        <td><span class="status-badge ${statusClass(h.status)}">${esc(h.status)}</span></td><td>${esc(h.technician)}</td>
        <td><div class="history-photo-actions">
          ${h.beforePhoto ? `<button type="button" class="ghost" data-view-history-photo="${index}" data-photo-side="before">BEFORE</button>` : '<span class="photo-state missing">No BEFORE</span>'}
          ${h.afterPhoto ? `<button type="button" class="ghost" data-view-history-photo="${index}" data-photo-side="after">AFTER</button>` : '<span class="photo-state missing">No AFTER</span>'}
        </div></td>
        <td><div class="table-actions"><button type="button" class="ghost edit-icon" data-edit-history="${index}">✏ Edit</button><button type="button" class="danger delete-icon" data-delete-history="${index}">🗑 Hapus</button></div></td></tr>`).join('')
        : `<tr><td colspan="9"><div class="empty-state">${query ? `History tidak ditemukan untuk “${esc(query)}”.` : 'Belum ada history.'}</div></td></tr>`;
      $$('[data-edit-history]').forEach(btn => btn.addEventListener('click', () => openHistoryDialog(Number(btn.dataset.editHistory))));
      $$('[data-delete-history]').forEach(btn => btn.addEventListener('click', () => deleteHistory(Number(btn.dataset.deleteHistory))));
      translateTree($('#history'));
      $$('[data-view-history-photo]').forEach(btn => btn.addEventListener('click', () => {
        const item = state.history[Number(btn.dataset.viewHistoryPhoto)];
        const side = btn.dataset.photoSide;
        if (!item) return;
        const photo = side === 'before' ? item.beforePhoto : item.afterPhoto;
        openPhotoViewer(photo, `${item.equipment} · ${item.point} · ${side.toUpperCase()}`);
      }));
    }

    $('#historySearch').addEventListener('input', scheduleHistorySearch);
    $('#historySearch').addEventListener('focus', renderHistorySuggestions);
    $('#historySearch').addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        renderHistory();
        $('#historySuggestions').classList.remove('show');
        focusFirstHistoryResult();
      } else if (event.key === 'Escape') {
        $('#historySuggestions').classList.remove('show');
      }
    });
    $('#historySearchBtn').addEventListener('click', () => {
      renderHistory();
      $('#historySuggestions').classList.remove('show');
      focusFirstHistoryResult();
    });
    $('#historySearchResetBtn').addEventListener('click', () => {
      $('#historySearch').value = '';
      $('#historySuggestions').classList.remove('show');
      renderHistory();
      $('#historySearch').focus();
    });
    $('#historySuggestions').addEventListener('click', event => {
      const option = event.target.closest('[data-history-suggestion]');
      if (!option) return;
      $('#historySearch').value = option.dataset.historySuggestion || '';
      $('#historySuggestions').classList.remove('show');
      renderHistory();
      focusFirstHistoryResult();
    });
    document.addEventListener('click', event => {
      if (!event.target.closest('#historySearchPanel')) $('#historySuggestions')?.classList.remove('show');
    });

    function deleteEquipment(id) {
      if(initialState.equipment.some(e=>e.id===id)) { toast('Equipment sumber PDF tidak dapat dihapus.'); return; }
      const item = state.equipment.find(e => e.id === id);
      if (!item) return;
      if (!confirm(`Hapus equipment ${item.tag} · ${item.name}?`)) return;
      state.equipment = state.equipment.filter(e => e.id !== id);
      save(); refreshAreaFilter(); renderAll(); toast('Equipment berhasil dihapus.');
    }

    function deleteLubricant(id) {
      const item = state.lubricants.find(l => l.id === id);
      if (!item) return;
      if (!confirm(`Hapus lubricant ${item.name}?`)) return;
      state.lubricants = state.lubricants.filter(l => l.id !== id);
      save(); renderAll(); toast('Lubricant berhasil dihapus.');
    }

    function deleteHistory(index) {
      const item = state.history[index];
      if (!item) return;
      if (!confirm(`Hapus history ${item.equipment} · ${item.point}?`)) return;
      state.history.splice(index, 1);
      save(); renderAll(); toast('History berhasil dihapus.');
    }

    $('#lubricationPointSearch').addEventListener('input', renderRoute);
    $('#lubricationPointAreaFilter').addEventListener('change', renderRoute);
    $('#lubricationPointStatusFilter').addEventListener('change', renderRoute);

    const pointDialog = $('#pointDialog');
    const pointForm = $('#pointForm');
    const photoViewerDialog = $('#photoViewerDialog');
    let pointEvidenceDraft = {before:'', after:''};
    let activePointId = '';
    let mediaPickerState = {active:false, side:'', returnTimer:null};

    function openPhotoViewer(src, title='Photo Evidence') {
      if (!src) { toast('Foto belum tersedia.'); return; }
      $('#photoViewerTitle').textContent = tx(title);
      $('#photoViewerImage').src = src;
      if (!photoViewerDialog.open) photoViewerDialog.showModal();
    }
    $('#closePhotoViewerBtn').addEventListener('click', () => photoViewerDialog.close());
    photoViewerDialog.addEventListener('cancel', e => { e.preventDefault(); photoViewerDialog.close(); });

    function renderPointEvidencePreview() {
      const renderOne = (side, label, emptyText) => {
        const mount = $(`#${side}PhotoPreview`);
        if (!mount) return;
        const src = pointEvidenceDraft[side];
        mount.innerHTML = src
          ? `<img src="${src}" alt="${label}" data-preview-evidence="${side}" loading="eager" />`
          : (emptyText || `Belum ada foto ${label}`);
      };
      renderOne('before','BEFORE','Belum ada foto BEFORE');
      renderOne('after','AFTER','Belum ada foto AFTER');
      $$('[data-preview-evidence]').forEach(img => img.addEventListener('click', () => {
        const side = img.dataset.previewEvidence;
        const title = `Preview ${side.toUpperCase()}`;
        openPhotoViewer(pointEvidenceDraft[side], tx(title));
      }));
      translateTree(pointDialog);
    }

    function pointDraftSnapshot() {
      if (!activePointId) return null;
      return {
        pointId:activePointId,
        status:$('#pointStatusSelect')?.value || 'Done',
        quantity:pointForm.elements.quantity?.value || '',
        condition:pointForm.elements.condition?.value || '',
        reason:pointForm.elements.reason?.value || '',
        evidence:{...pointEvidenceDraft},
        dialogScrollTop:pointDialog.scrollTop || 0,
        savedAt:Date.now()
      };
    }

    function savePointDraftSession() {
      const draft = pointDraftSnapshot();
      if (!draft) return;
      try { sessionStorage.setItem(routeDraftSessionKey, JSON.stringify(draft)); } catch (_) {}
    }

    function readPointDraftSession() {
      try { return JSON.parse(sessionStorage.getItem(routeDraftSessionKey) || 'null'); }
      catch (_) { return null; }
    }

    function clearPointDraftSession() {
      try { sessionStorage.removeItem(routeDraftSessionKey); } catch (_) {}
      activePointId = '';
    }

    function applyPointDraft(draft) {
      if (!draft || !draft.pointId) return false;
      const item = allPoints().find(x => x.id === draft.pointId);
      if (!item) { clearPointDraftSession(); return false; }
      activePointId = draft.pointId;
      $('#pointDialogTitle').textContent = `${item.equipment.tag} · ${item.name}`;
      pointForm.elements.pointId.value = draft.pointId;
      pointForm.elements.quantity.value = draft.quantity ?? item.qty ?? '';
      pointForm.elements.condition.value = draft.condition || '';
      pointForm.elements.reason.value = draft.reason || '';
      $('#pointStatusSelect').value = draft.status === 'Skipped' ? 'Skipped' : 'Done';
      pointEvidenceDraft = {
        before:draft.evidence?.before || item.evidence?.before || '',
        after:draft.evidence?.after || item.evidence?.after || '',
      };
      $('#pointTechnicalReferenceBody').innerHTML = `
        <div class="meta-grid">
          <div class="meta-row"><span>Equipment</span><b>${esc(item.equipment.tag)} · ${esc(item.equipment.name)}</b></div>
          <div class="meta-row"><span>Lubricant Specification</span><b>${esc(item.lubricant)}</b></div>
          <div class="meta-row"><span>Reference Quantity</span><b>${esc(item.qty || '-')}</b></div>
          <div class="meta-row"><span>Lubrication Interval</span><b>${esc(item.interval || '-')}</b></div>
        </div>`;
      toggleReason();
      renderPointEvidencePreview();
      if (!pointDialog.open) pointDialog.showModal();
      translateTree(pointDialog);
      requestAnimationFrame(() => { pointDialog.scrollTop = Number(draft.dialogScrollTop || 0); });
      return true;
    }

    function restorePointDraftSession() {
      const draft = readPointDraftSession();
      if (!draft?.pointId || !isLoggedIn()) return false;
      goPage('route');
      return applyPointDraft(draft);
    }

    async function optimizeEvidencePhoto(file) {
      if (!file) throw new Error('Foto tidak dipilih.');
      const looksLikeImage = String(file.type || '').startsWith('image/') || /\.(jpe?g|png|webp|heic|heif)$/i.test(file.name || '');
      if (!looksLikeImage) throw new Error('File harus berupa gambar.');
      if (file.size > 20 * 1024 * 1024) throw new Error('Ukuran foto maksimal 20 MB.');
      let bitmap;
      try {
        bitmap = await loadImageFile(file);
      } catch (_) {
        // Fallback untuk beberapa browser mobile/format kamera yang gagal di createImageBitmap.
        bitmap = await new Promise((resolve, reject) => {
          const image = new Image();
          const reader = new FileReader();
          reader.onload = () => { image.onload = () => resolve(image); image.onerror = () => reject(new Error('Format foto tidak dapat ditampilkan browser.')); image.src = reader.result; };
          reader.onerror = () => reject(new Error('Foto tidak dapat dibaca.'));
          reader.readAsDataURL(file);
        });
      }
      const sw = bitmap.width || bitmap.naturalWidth, sh = bitmap.height || bitmap.naturalHeight;
      if (!sw || !sh) throw new Error('Dimensi foto tidak terbaca.');
      const maxSide = 1100;
      const scale = Math.min(1, maxSide / Math.max(sw, sh));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(sw * scale));
      canvas.height = Math.max(1, Math.round(sh * scale));
      const ctx = canvas.getContext('2d');
      ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close?.();
      // Kualitas cukup jelas untuk membaca display thermometer tetapi tetap ringan untuk localStorage.
      return canvas.toDataURL('image/jpeg', .74);
    }

    async function handleEvidenceFile(file, side) {
      if (!file) return false;
      try {
        pointEvidenceDraft[side] = await optimizeEvidencePhoto(file);
        renderPointEvidencePreview();
        savePointDraftSession();
        toast(`Foto ${side.toUpperCase()} berhasil ditampilkan.`);
        return true;
      } catch (err) {
        toast(err.message || 'Foto tidak dapat diproses.');
        return false;
      }
    }

    function openPointDialog(pointId) {
      const item = allPoints().find(x => x.id === pointId); if (!item) return;
      activePointId = pointId;
      $('#pointDialogTitle').textContent = `${item.equipment.tag} · ${item.name}`;
      pointForm.elements.pointId.value = pointId;
      pointForm.elements.quantity.value = item.qty || '';
      pointForm.elements.condition.value = '';
      pointForm.elements.reason.value = '';
      $('#pointStatusSelect').value = item.status === 'Skipped' ? 'Skipped' : 'Done';
      pointEvidenceDraft = {before:item.evidence?.before || '', after:item.evidence?.after || ''};
      $('#pointTechnicalReferenceBody').innerHTML = `
        <div class="meta-grid">
          <div class="meta-row"><span>Equipment</span><b>${esc(item.equipment.tag)} · ${esc(item.equipment.name)}</b></div>
          <div class="meta-row"><span>Lubricant Specification</span><b>${esc(item.lubricant)}</b></div>
          <div class="meta-row"><span>Reference Quantity</span><b>${esc(item.qty || '-')}</b></div>
          <div class="meta-row"><span>Lubrication Interval</span><b>${esc(item.interval || '-')}</b></div>
        </div>`;
      toggleReason();
      renderPointEvidencePreview();
      if (!pointDialog.open) pointDialog.showModal();
      translateTree(pointDialog);
      savePointDraftSession();
    }

    const toggleReason = () => $('#reasonField').hidden = $('#pointStatusSelect').value !== 'Skipped';
    $('#pointStatusSelect').addEventListener('change', () => { toggleReason(); savePointDraftSession(); });
    ['input','change'].forEach(evt => pointForm.addEventListener(evt, e => {
      if (!pointDialog.open || !activePointId || e.target.type === 'file') return;
      savePointDraftSession();
    }));

    const evidenceInputs = {
      beforeCamera: $('#beforeCameraInput'), beforeGallery: $('#beforeGalleryInput'),
      afterCamera: $('#afterCameraInput'), afterGallery: $('#afterGalleryInput')
    };

    function launchEvidencePicker(input, side) {
      if (!activePointId) { toast('Buka lubrication point terlebih dahulu.'); return; }
      savePointDraftSession();
      mediaPickerState.active = true;
      mediaPickerState.side = side;
      clearTimeout(mediaPickerState.returnTimer);
      // Reset supaya foto yang sama tetap memicu event change jika dipilih kembali.
      input.value = '';
      input.click();
    }

    async function evidenceInputChanged(input, side) {
      const file = input.files?.[0];
      mediaPickerState.active = false;
      clearTimeout(mediaPickerState.returnTimer);
      if (file) await handleEvidenceFile(file, side);
      else {
        // Beberapa browser mengirim change tanpa file ketika picker dibatalkan.
        restorePointDraftSession();
      }
      input.value = '';
      savePointDraftSession();
    }

    $('#beforeCameraBtn').addEventListener('click', () => launchEvidencePicker(evidenceInputs.beforeCamera, 'before'));
    $('#beforeGalleryBtn').addEventListener('click', () => launchEvidencePicker(evidenceInputs.beforeGallery, 'before'));
    $('#afterCameraBtn').addEventListener('click', () => launchEvidencePicker(evidenceInputs.afterCamera, 'after'));
    $('#afterGalleryBtn').addEventListener('click', () => launchEvidencePicker(evidenceInputs.afterGallery, 'after'));

    evidenceInputs.beforeCamera.addEventListener('change', () => evidenceInputChanged(evidenceInputs.beforeCamera, 'before'));
    evidenceInputs.beforeGallery.addEventListener('change', () => evidenceInputChanged(evidenceInputs.beforeGallery, 'before'));
    evidenceInputs.afterCamera.addEventListener('change', () => evidenceInputChanged(evidenceInputs.afterCamera, 'after'));
    evidenceInputs.afterGallery.addEventListener('change', () => evidenceInputChanged(evidenceInputs.afterGallery, 'after'));

    function recoverAfterMediaPicker() {
      if (!mediaPickerState.active) return;
      clearTimeout(mediaPickerState.returnTimer);
      mediaPickerState.returnTimer = setTimeout(() => {
        if (!mediaPickerState.active) return;
        // Tidak ada event change = pengguna kemungkinan menekan Back/Cancel di kamera/galeri.
        mediaPickerState.active = false;
        restorePointDraftSession();
        toast('Pengambilan foto dibatalkan. Form tetap pada lubrication point yang sama.');
      }, 650);
    }
    window.addEventListener('focus', recoverAfterMediaPicker);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) recoverAfterMediaPicker(); });
    window.addEventListener('pageshow', () => { if (readPointDraftSession()?.pointId) setTimeout(() => restorePointDraftSession(), 80); });

    $('#removeBeforePhotoBtn').addEventListener('click', () => { pointEvidenceDraft.before=''; renderPointEvidencePreview(); savePointDraftSession(); });
    $('#removeAfterPhotoBtn').addEventListener('click', () => { pointEvidenceDraft.after=''; renderPointEvidencePreview(); savePointDraftSession(); });

    pointForm.addEventListener('submit', e => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget); const id = fd.get('pointId');
      const item = allPoints().find(x => x.id === id); if (!item) return;
      const status = fd.get('status');
      if (status === 'Skipped' && !String(fd.get('reason')).trim()) { toast('Reason wajib diisi untuk lubrication point yang tidak dapat dikerjakan.'); return; }
      if (!pointEvidenceDraft.before) { toast('Foto BEFORE kondisi aktual wajib dilampirkan.'); return; }
      if (status === 'Done' && !pointEvidenceDraft.after) { toast('Foto AFTER setelah greasing/perbaikan wajib dilampirkan.'); return; }
      const original = item.equipment.points.find(p => p.id === id);
      original.status = status;
      original.evidence = {...pointEvidenceDraft};
      const historyItem = {
        date:new Date().toLocaleString('sv-SE',{hour12:false}).replace(',',''), equipment:item.equipment.tag, point:item.name,
        lubricant:item.lubricant, qty:String(fd.get('quantity') || '').trim(), status, technician:account.fullName,
        condition:String(fd.get('condition') || '').trim(), reason:String(fd.get('reason') || '').trim(),
        beforePhoto:pointEvidenceDraft.before, afterPhoto:pointEvidenceDraft.after
      };
      state.history.unshift(historyItem);
      if (!save()) { state.history.shift(); return; }
      pointDialog.close(); pointForm.reset(); pointEvidenceDraft={before:'',after:''}; clearPointDraftSession(); toggleReason(); renderAll(); toast('Execution status dan photo evidence berhasil disimpan.');
    });

    const equipmentDialog = $('#equipmentDialog');
    const equipmentForm = $('#equipmentForm');
    function resetEquipmentForm() {
      equipmentForm.reset();
      equipmentForm.elements.editId.value = '';
      equipmentForm.elements.status.value = 'Normal';
      equipmentForm.elements.operationalStatus.value = 'Operasional';
      $('#equipmentDialogHeading').textContent = 'Tambah Equipment';
      $('#equipmentDialogDescription').textContent = 'Input technical asset data, lubricant specification, capacity, dan greasing point quantity.';
      $('#saveEquipmentBtn').textContent = 'Save Equipment Data';
      $('#greasePointCountPreview').textContent = '0 point';
    }
    function openEquipmentDialog(id='') {
      resetEquipmentForm();
      if (id) {
        const item = state.equipment.find(e => e.id === id);
        if (!item) return;
        equipmentForm.elements.editId.value = item.id;
        equipmentForm.elements.tag.value = item.tag;
        equipmentForm.elements.unitNumber.value = item.unitNumber || item.tag || '';
        equipmentForm.elements.name.value = item.name;
        equipmentForm.elements.manufactureYear.value = item.manufactureYear === '-' ? '' : (item.manufactureYear || '');
        equipmentForm.elements.powerSource.value = item.powerSource || '';
        equipmentForm.elements.operationalStatus.value = item.operationalStatus || 'Operasional';
        equipmentForm.elements.area.value = item.area;
        equipmentForm.elements.criticality.value = item.criticality;
        equipmentForm.elements.status.value = item.status || 'Normal';
        equipmentForm.elements.oil.value = item.oil || '';
        equipmentForm.elements.oilCapacity.value = item.oilCapacity || '';
        equipmentForm.elements.grease.value = item.grease || '';
        equipmentForm.elements.greaseCapacity.value = item.greaseCapacity || '';
        equipmentForm.elements.greasePointDetails.value = greasePointDetailsText(item);
        $('#greasePointCountPreview').textContent = `${greasePointsFor(item).length} point`;
        $('#equipmentDialogHeading').textContent = 'Edit Equipment';
        $('#equipmentDialogDescription').textContent = `Perbarui data ${item.tag} tanpa membuat equipment baru.`;
        $('#saveEquipmentBtn').textContent = 'Save Technical Changes';
      }
      const ref=initialState.equipment.some(e=>e.id===equipmentForm.elements.editId.value);
      ['tag','unitNumber','name','area','oil','grease','oilCapacity','greaseCapacity','greasePointDetails'].forEach(k=>{if(equipmentForm.elements[k])equipmentForm.elements[k].readOnly=ref;});
      if(ref) $('#equipmentDialogDescription').textContent='Identitas teknis dapat diedit. Data pelumasan mengikuti PDF sumber.';
      equipmentDialog.showModal();
      translateTree(equipmentDialog);
    }
    $('#addEquipmentBtn').addEventListener('click', () => openEquipmentDialog());
    equipmentForm.elements.greasePointDetails.addEventListener('input', e => {
      const count = String(e.currentTarget.value || '').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).length;
      $('#greasePointCountPreview').textContent = `${count} point`;
    });
    $$('[data-go="equipment"]').filter(x => x.textContent.includes('Tambah')).forEach(x => x.addEventListener('click', () => setTimeout(() => openEquipmentDialog(), 100)));
    equipmentForm.addEventListener('submit', e => {
      e.preventDefault();
      if (!equipmentForm.reportValidity()) return;
      const fd = new FormData(equipmentForm);
      const editId = String(fd.get('editId') || '');
      const tag = String(fd.get('tag')).trim().toUpperCase();
      if (state.equipment.some(x => x.id !== editId && x.tag.toUpperCase() === tag)) { toast('Tag equipment sudah terdaftar.'); return; }
      const unitNumber = String(fd.get('unitNumber')).trim().toUpperCase();
      if (state.equipment.some(x => x.id !== editId && String(x.unitNumber || '').toUpperCase() === unitNumber)) { toast('Nomor unit sudah terdaftar.'); return; }
      if (editId) {
        const item = state.equipment.find(x => x.id === editId);
        if (!item) { toast('Equipment tidak ditemukan.'); return; }
        const oldGrease = item.grease;
        Object.assign(item, {
          tag,
          unitNumber:String(fd.get('unitNumber')).trim(),
          name:String(fd.get('name')).trim(),
          manufactureYear:String(fd.get('manufactureYear')).trim(),
          powerSource:String(fd.get('powerSource')).trim(),
          operationalStatus:String(fd.get('operationalStatus')).trim(),
          area:String(fd.get('area')).trim(),
          criticality:fd.get('criticality'),
          status:fd.get('status'),
          oil:String(fd.get('oil')).trim(),
          oilCapacity:String(fd.get('oilCapacity') || '').trim(),
          grease:String(fd.get('grease')).trim(),
          greaseCapacity:String(fd.get('greaseCapacity') || '').trim()
        });
        const nonGreasePoints = item.points.filter(p => String(p.lubricant || '').trim().toLowerCase() !== String(oldGrease || '').trim().toLowerCase());
        const editedGreasePoints = parseGreasePointDetails(fd.get('greasePointDetails'), item.grease, item.points);
        item.points = [...editedGreasePoints, ...nonGreasePoints];
        toast('Equipment berhasil diperbarui.');
      } else {
        const id = 'eq'+Date.now();
        state.equipment.push({
          id, tag,
          unitNumber:String(fd.get('unitNumber')).trim(),
          name:String(fd.get('name')).trim(),
          manufactureYear:String(fd.get('manufactureYear')).trim(),
          powerSource:String(fd.get('powerSource')).trim(),
          operationalStatus:String(fd.get('operationalStatus')).trim(),
          area:String(fd.get('area')).trim(),
          criticality:fd.get('criticality'),
          oil:String(fd.get('oil')).trim(),
          oilCapacity:String(fd.get('oilCapacity') || '').trim(),
          grease:String(fd.get('grease')).trim(),
          greaseCapacity:String(fd.get('greaseCapacity') || '').trim(),
          status:fd.get('status') || 'Normal',
          points:parseGreasePointDetails(fd.get('greasePointDetails'), String(fd.get('grease')).trim(), [])
        });
        toast('Equipment baru berhasil ditambahkan.');
      }
      const reference = initialState.equipment.find(e=>e.id===editId);
      if(reference) { const item=state.equipment.find(e=>e.id===editId); ['tag','unitNumber','name','area','oil','grease','oilCapacity','greaseCapacity','points'].forEach(k=>item[k]=JSON.parse(JSON.stringify(reference[k]))); }
      if(!save()) return; equipmentDialog.close(); resetEquipmentForm(); refreshAreaFilter(); renderAll();
    });

    const lubricantDialog = $('#lubricantDialog');
    const lubricantForm = $('#lubricantForm');
    function resetLubricantForm() {
      lubricantForm.reset();
      lubricantForm.elements.editId.value = '';
      lubricantForm.elements.stock.value = '10';
      lubricantForm.elements.minimum.value = '5';
      $('#lubricantDialogHeading').textContent = 'Tambah Lubricant';
      $('#lubricantDialogDescription').textContent = 'Master grease atau oil baru.';
      $('#saveLubricantBtn').textContent = 'Simpan';
    }
    function openLubricantDialog(id='') {
      resetLubricantForm();
      if (id) {
        const item = state.lubricants.find(l => l.id === id);
        if (!item) return;
        lubricantForm.elements.editId.value = item.id;
        lubricantForm.elements.name.value = item.name;
        lubricantForm.elements.type.value = item.type;
        lubricantForm.elements.grade.value = item.grade;
        lubricantForm.elements.application.value = item.application;
        lubricantForm.elements.stock.value = item.stock;
        lubricantForm.elements.minimum.value = item.minimum;
        $('#lubricantDialogHeading').textContent = 'Edit Lubricant';
        $('#lubricantDialogDescription').textContent = `Perbarui master ${item.name} tanpa membuat data baru.`;
        $('#saveLubricantBtn').textContent = 'Simpan Perubahan';
      }
      lubricantDialog.showModal();
      translateTree(lubricantDialog);
    }
    $('#addLubricantBtn').addEventListener('click', () => openLubricantDialog());
    lubricantForm.addEventListener('submit', e => {
      e.preventDefault();
      if (!lubricantForm.reportValidity()) return;
      const fd = new FormData(lubricantForm);
      const editId = String(fd.get('editId') || '');
      const values = {name:String(fd.get('name')).trim(), type:fd.get('type'), grade:String(fd.get('grade')).trim(), application:String(fd.get('application')).trim(), stock:Number(fd.get('stock')), minimum:Number(fd.get('minimum'))};
      if (editId) {
        const item = state.lubricants.find(l => l.id === editId);
        if (!item) { toast('Lubricant tidak ditemukan.'); return; }
        Object.assign(item, values);
        toast('Lubricant berhasil diperbarui.');
      } else {
        state.lubricants.push({id:'l'+Date.now(), ...values});
        toast('Lubricant berhasil ditambahkan.');
      }
      save(); lubricantDialog.close(); resetLubricantForm(); renderAll();
    });

    const historyDialog = $('#historyDialog');
    const historyForm = $('#historyForm');
    function openHistoryDialog(index) {
      const item = state.history[index];
      if (!item) return;
      historyForm.reset();
      historyForm.elements.editIndex.value = String(index);
      historyForm.elements.date.value = item.date;
      historyForm.elements.equipment.value = item.equipment;
      historyForm.elements.point.value = item.point;
      historyForm.elements.lubricant.value = item.lubricant;
      historyForm.elements.qty.value = item.qty;
      historyForm.elements.status.value = item.status;
      historyForm.elements.technician.value = item.technician;
      historyDialog.showModal();
      translateTree(historyDialog);
    }
    historyForm.addEventListener('submit', e => {
      e.preventDefault();
      if (!historyForm.reportValidity()) return;
      const fd = new FormData(historyForm);
      const index = Number(fd.get('editIndex'));
      if (!Number.isInteger(index) || !state.history[index]) { toast('History tidak ditemukan.'); return; }
      state.history[index] = {...state.history[index], date:String(fd.get('date')).trim(), equipment:String(fd.get('equipment')).trim(), point:String(fd.get('point')).trim(), lubricant:String(fd.get('lubricant')).trim(), qty:String(fd.get('qty')).trim(), status:fd.get('status'), technician:String(fd.get('technician')).trim()};
      save(); historyDialog.close(); historyForm.reset(); renderAll(); toast('History berhasil diperbarui.');
    });

    function cancelDialog(dialogId) {
      const dialog = document.getElementById(dialogId);
      if (!dialog) return;
      if (dialogId === 'equipmentDialog') resetEquipmentForm();
      if (dialogId === 'lubricantDialog') resetLubricantForm();
      if (dialogId === 'pointDialog') {
        pointForm.reset(); pointEvidenceDraft={before:'',after:'',temperature:''}; clearPointDraftSession(); renderPointEvidencePreview(); toggleReason();
      }
      if (dialogId === 'historyDialog') historyForm.reset();
      if (dialog.open) dialog.close();
    }
    $$('[data-cancel-dialog]').forEach(btn => btn.addEventListener('click', () => cancelDialog(btn.dataset.cancelDialog)));
    [equipmentDialog, lubricantDialog, pointDialog, historyDialog].forEach(dialog => dialog.addEventListener('cancel', e => {
      e.preventDefault();
      // Native camera/gallery pada beberapa HP dapat memicu cancel pada <dialog>. Jangan reset form saat picker masih aktif.
      if (dialog.id === 'pointDialog' && mediaPickerState.active) return;
      cancelDialog(dialog.id);
    }));

    function refreshDatabaseAreaFilter() {
      const current=$('#databaseAreaFilter')?.value || '';
      const areas=[...new Set((state.lubricationDatabase||[]).map(r=>r.area).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
      $('#databaseAreaFilter').innerHTML='<option value="">Semua Area</option>'+areas.map(a=>`<option>${esc(a)}</option>`).join('');
      if(areas.includes(current)) $('#databaseAreaFilter').value=current;
      translateTree($('#databaseAreaFilter'));
    }
    let dbTimer; $('#databaseSearch').addEventListener('input',()=>{clearTimeout(dbTimer);dbTimer=setTimeout(()=>{lubricationDatabasePage=1;renderLubricationDatabase(false);},160);});
    $('#databaseTypeFilter').addEventListener('change',()=>{lubricationDatabasePage=1;renderLubricationDatabase(false);});
    $('#databaseAreaFilter').addEventListener('change',()=>{lubricationDatabasePage=1;renderLubricationDatabase(false);});
    $('#databasePageSize').addEventListener('change',()=>{lubricationDatabasePage=1;renderLubricationDatabase(false);});
    $('#exportLubricationDatabaseBtn').addEventListener('click', () => {
      const keys = ['area','equipment','description','component','modifier','type','brand','name','oilLifeTarget','topUpFactor','capacity','units','workingHrsYear','rateHr','consumptionMtH','notes','sourcePage'];
      const csv = '\ufeff'+[keys,...state.lubricationDatabase.map(r=>keys.map(k=>r[k]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
      QIESaveFile('Lubricant_Database_2026.csv','text/csv',csv);
    });

    $('#exportBtn').addEventListener('click', () => {
      const rows = [['Tanggal','Equipment','Titik','Lubricant','Qty','Status','Teknisi','Condition','Reason','Before Photo','After Photo'], ...state.history.map(h => [h.date,h.equipment,h.point,h.lubricant,h.qty,h.status,h.technician,h.condition||'',h.reason||'',h.beforePhoto?'Available':'Not Available',h.afterPhoto?'Available':'Not Available'])];
      const csv = rows.map(r => r.map(v => `"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download='SLM_History.csv'; a.click(); URL.revokeObjectURL(a.href);
    });

    $('#closeEquipmentQrBtn').addEventListener('click', () => equipmentQrDialog.close());
    $('#cancelEquipmentQrBtn').addEventListener('click', () => equipmentQrDialog.close());
    $('#downloadEquipmentQrBtn').addEventListener('click', downloadActiveEquipmentQr);
    $('#printEquipmentQrBtn').addEventListener('click', printActiveEquipmentQr);
    equipmentQrDialog.addEventListener('cancel', e => { e.preventDefault(); equipmentQrDialog.close(); });
    $('#closeEquipmentDetailBtn').addEventListener('click', () => equipmentDetailDialog.close());
    $('#closeEquipmentDetailActionBtn').addEventListener('click', () => equipmentDetailDialog.close());
    $('#detailViewQrBtn').addEventListener('click', () => { if (!activeDetailEquipment) return; const unit=activeDetailEquipment.unitNumber; equipmentDetailDialog.close(); setTimeout(() => openEquipmentQr(unit), 80); });
    $('#detailEditEquipmentBtn').addEventListener('click', () => { if (!activeDetailEquipment) return; const id=activeDetailEquipment.id; equipmentDetailDialog.close(); setTimeout(() => openEquipmentDialog(id), 80); });
    equipmentDetailDialog.addEventListener('cancel', e => { e.preventDefault(); equipmentDetailDialog.close(); });

    // Equipment identification: exactly two choices — live camera QR scan or QR image from gallery.
    const scannerDialog = $('#qrScannerDialog');
    const scannerStatus = $('#qrScannerStatus');
    const cameraInput = $('#qrCameraInput');
    const galleryInput = $('#qrGalleryInput');
    const previewCanvas = $('#qrPreviewCanvas');
    const previewShell = $('#qrPreviewShell');
    const selectedFileName = $('#qrSelectedFileName');
    const scanCanvas = $('#qrScannerCanvas');
    let detector = null;

    const setScanStatus = (message, type='') => {
      scannerStatus.textContent = tx(message);
      scannerStatus.className = `qr-status${type ? ' '+type : ''}`;
    };

    const compactCode = value => String(value || '')
      .trim().toLowerCase().replace(/[^a-z0-9]/g, '');

    function normalizeEquipmentCode(raw) {
      let text = String(raw || '').trim();
      if (!text) return '';

      try {
        const parsed = JSON.parse(text);
        if (parsed && typeof parsed === 'object') {
          text = parsed.unitNumber || parsed.nomorUnit || parsed.nomor_unit || parsed.tag ||
                 parsed.equipment || parsed.asset || parsed.code || parsed.id || text;
        }
      } catch (_) {}

      try {
        const url = new URL(text);
        const hashEquipment = url.hash.match(/(?:^#|&)equipment=([^&]+)/i)?.[1];
        text = url.searchParams.get('unitNumber') || url.searchParams.get('nomorUnit') ||
               url.searchParams.get('tag') || url.searchParams.get('equipment') ||
               url.searchParams.get('asset') || url.searchParams.get('id') ||
               (hashEquipment ? decodeURIComponent(hashEquipment) : '') ||
               decodeURIComponent(url.pathname.split('/').filter(Boolean).pop() || text);
      } catch (_) {}

      text = String(text).trim();
      const slmPayload = text.match(/^SLM\s*[:|_-]?\s*EQUIPMENT\s*[:|=#_-]\s*([a-z0-9._/-]+)/i);
      if (slmPayload) text = slmPayload[1];
      const labeled = text.match(/(?:nomor\s*unit|unit\s*number|equipment|asset|tag|kode)\s*[:=#-]\s*([a-z0-9._/-]+)/i);
      if (labeled) text = labeled[1];
      return text.replace(/^['"\s]+|['"\s]+$/g, '').trim();
    }

    function findEquipmentByCode(raw) {
      const value = normalizeEquipmentCode(raw);
      if (!value) return { value:'', equipment:null };
      const needle = value.toLowerCase();
      const compactNeedle = compactCode(value);
      const exactFields = e => [e.unitNumber, e.tag].filter(Boolean);
      let equipment = state.equipment.find(e => exactFields(e).some(v => String(v).toLowerCase() === needle));
      if (!equipment && compactNeedle) {
        equipment = state.equipment.find(e => exactFields(e).some(v => compactCode(v) === compactNeedle));
      }
      if (!equipment) {
        equipment = state.equipment.find(e => {
          const haystack = [e.unitNumber, e.tag, e.name, e.area].filter(Boolean).join(' ').toLowerCase();
          return haystack.includes(needle);
        });
      }
      return { value, equipment };
    }

    function revealEquipment(equipment, sourceLabel) {
      $('#equipmentAreaFilter').value = '';
      $('#equipmentSearch').value = equipment.unitNumber || equipment.tag;
      goPage('equipment');
      renderEquipment();
      if (scannerDialog.open) scannerDialog.close();
      toast(`${equipment.unitNumber || equipment.tag} ditemukan melalui ${sourceLabel}.`);
      requestAnimationFrame(() => {
        const cards = $$('.equipment-card');
        const card = cards.find(el => el.dataset.tag === equipment.tag);
        if (card) { card.classList.add('qr-match'); card.scrollIntoView({behavior:'smooth', block:'center'}); setTimeout(() => card.classList.remove('qr-match'), 3200); }
        setTimeout(() => openEquipmentDetail(equipment), 180);
      });
    }

    function applyIdentification(raw, sourceLabel='QR Code') {
      const result = findEquipmentByCode(raw);
      if (!result.value) {
        setScanStatus('QR Code belum menghasilkan kode equipment yang valid.', 'error');
        return false;
      }
      if (!result.equipment) {
        setScanStatus(`“${result.value}” berhasil dibaca, tetapi equipment tersebut belum terdaftar.`, 'error');
        return false;
      }
      setScanStatus(`Equipment ditemukan: ${result.equipment.unitNumber || result.equipment.tag} — ${result.equipment.name}`, 'success');
      setTimeout(() => revealEquipment(result.equipment, sourceLabel), 280);
      return true;
    }

    async function decodeWithNativeBarcodeDetector(canvas) {
      if (!('BarcodeDetector' in window)) return '';
      try {
        detector ||= new BarcodeDetector({formats:['qr_code']});
        const results = await detector.detect(canvas);
        return results?.[0]?.rawValue || '';
      } catch (_) { return ''; }
    }

    function decodeWithJsQR(canvas) {
      if (typeof window.jsQR !== 'function') return '';
      try {
        const ctx = canvas.getContext('2d', {willReadFrequently:true});
        const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = window.jsQR(image.data, canvas.width, canvas.height, {inversionAttempts:'attemptBoth'});
        return code?.data || '';
      } catch (_) { return ''; }
    }

    function makeProcessedCanvas(source, mode) {
      const canvas = document.createElement('canvas');
      canvas.width = source.width; canvas.height = source.height;
      const ctx = canvas.getContext('2d', {willReadFrequently:true});
      ctx.drawImage(source, 0, 0);
      const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = image.data;
      for (let i=0; i<data.length; i+=4) {
        const gray = Math.round(.299*data[i] + .587*data[i+1] + .114*data[i+2]);
        let value = gray;
        if (mode === 'contrast') value = gray < 128 ? 0 : 255;
        if (mode === 'bright') value = gray < 175 ? 0 : 255;
        data[i] = data[i+1] = data[i+2] = value;
      }
      ctx.putImageData(image, 0, 0);
      return canvas;
    }

    async function decodeQrFromCanvas(canvas) {
      let raw = await decodeWithNativeBarcodeDetector(canvas);
      if (raw) return raw;
      raw = decodeWithJsQR(canvas);
      if (raw) return raw;
      for (const mode of ['contrast','bright']) {
        const processed = makeProcessedCanvas(canvas, mode);
        raw = await decodeWithNativeBarcodeDetector(processed) || decodeWithJsQR(processed);
        if (raw) return raw;
      }
      return '';
    }

    function loadImageFile(file) {
      if ('createImageBitmap' in window) return createImageBitmap(file);
      return new Promise((resolve, reject) => {
        const image = new Image();
        const url = URL.createObjectURL(file);
        image.onload = () => { URL.revokeObjectURL(url); resolve(image); };
        image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Gambar tidak dapat dibuka')); };
        image.src = url;
      });
    }

    async function scanImageFile(file, sourceLabel) {
      if (!file) return;
      if (!String(file.type || '').startsWith('image/')) {
        setScanStatus('File harus berupa gambar JPG, PNG, WEBP, atau BMP.', 'error');
        return;
      }
      if (file.size > 20 * 1024 * 1024) {
        setScanStatus('Ukuran gambar terlalu besar. Gunakan gambar maksimal 20 MB.', 'error');
        return;
      }

      selectedFileName.textContent = file.name || 'Foto QR';
      setScanStatus('Memproses gambar dan mencari QR Code…', 'loading');
      try {
        const bitmap = await loadImageFile(file);
        const sourceWidth = bitmap.width || bitmap.naturalWidth;
        const sourceHeight = bitmap.height || bitmap.naturalHeight;
        const maxSide = 2200;
        const scale = Math.min(1, maxSide / Math.max(sourceWidth, sourceHeight));
        const width = Math.max(1, Math.round(sourceWidth * scale));
        const height = Math.max(1, Math.round(sourceHeight * scale));

        const ctx = previewCanvas.getContext('2d', {willReadFrequently:true});
        previewCanvas.width = width; previewCanvas.height = height;
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(bitmap, 0, 0, width, height);
        previewShell.classList.add('show');

        scanCanvas.width = width; scanCanvas.height = height;
        scanCanvas.getContext('2d', {willReadFrequently:true}).drawImage(previewCanvas, 0, 0);
        const raw = await decodeQrFromCanvas(scanCanvas);
        bitmap.close?.();

        if (raw) {
          applyIdentification(raw, sourceLabel);
        } else if (!('BarcodeDetector' in window) && typeof window.jsQR !== 'function') {
          setScanStatus('Pembaca QR belum tersedia di browser ini. Pastikan internet aktif saat pertama membuka aplikasi, lalu coba Kamera atau Galeri kembali.', 'error');
        } else {
          setScanStatus('QR belum terbaca. Pilih foto yang lebih dekat, terang, tegak, dan tidak terpotong.', 'error');
        }
      } catch (_) {
        setScanStatus('Gambar tidak dapat diproses. Coba pilih foto QR Code lain dari galeri.', 'error');
      }
    }

    function clearQrPreview() {
      if (cameraInput) cameraInput.value = '';
      galleryInput.value = '';
      previewShell.classList.remove('show');
      selectedFileName.textContent = tx('Foto QR Code');
      const ctx = previewCanvas.getContext('2d');
      ctx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
      setScanStatus('Pilih gambar dari galeri untuk membaca QR Equipment.');
    }

    function openScanner() {
      stopLiveQr();
      clearQrPreview();
      $('#chooseQrGalleryBtn')?.classList.remove('active');
      $('#startLiveQrBtn')?.classList.remove('active');
      scannerDialog.showModal();
    }

    function openPhoneCamera() {
      stopLiveQr();
      clearQrPreview();
      $('#startLiveQrBtn')?.classList.add('active');
      $('#chooseQrGalleryBtn')?.classList.remove('active');
      setScanStatus('Membuka kamera bawaan HP…', 'loading');
      cameraInput.value = '';
      // Pada browser HP, capture=environment meminta kamera belakang/native camera.
      cameraInput.click();
    }

    $('#scanQrOfflineBtn').addEventListener('click',()=>{toggleMobileMenu(false);openScanner();});
    $('#scanAssetBtn').addEventListener('click', openScanner);
    $('#startLiveQrBtn').addEventListener('click', openPhoneCamera);
    scannerDialog.addEventListener('close', stopLiveQr);

    cameraInput.addEventListener('change', () => {
      const file = cameraInput.files?.[0];
      if (file) {
        setScanStatus('Foto diterima. Membaca QR Code secara otomatis…', 'loading');
        scanImageFile(file, 'kamera HP');
      } else {
        $('#startLiveQrBtn')?.classList.remove('active');
        setScanStatus('Pengambilan foto dibatalkan. Pilih Kamera HP atau Galeri.');
      }
      cameraInput.value = '';
    });

    $('#chooseQrGalleryBtn').addEventListener('click', () => {
      stopLiveQr();
      clearQrPreview();
      $('#chooseQrGalleryBtn')?.classList.add('active');
      $('#startLiveQrBtn')?.classList.remove('active');
      galleryInput.value = '';
      galleryInput.click();
    });
    galleryInput.addEventListener('change', () => {
      const file = galleryInput.files?.[0];
      if (file) scanImageFile(file, 'foto dari galeri');
      else {
        $('#chooseQrGalleryBtn')?.classList.remove('active');
        setScanStatus('Pemilihan gambar dibatalkan. Pilih Kamera HP atau Galeri.');
      }
      galleryInput.value = '';
    });
    $('#closeQrScannerBtn').addEventListener('click', () => scannerDialog.close());
    scannerDialog.addEventListener('cancel', e => { e.preventDefault(); scannerDialog.close(); });
    window.addEventListener('pagehide', stopLiveQr);


    // ===== SLM + STANDALONE PM INTEGRATION =====

    function renderAll() { renderEquipment(); renderLubricationDatabase(false); }

    $('#backupQieBtn').addEventListener('click',()=>QIESaveFile('Quick_Identify_Backup.json','application/json',JSON.stringify({format:'QIE-backup-v1',savedAt:new Date().toISOString(),equipment:state.equipment},null,2)));
    $('#restoreQieBtn').addEventListener('click',()=>{if(window.QIEAndroid) QIEAndroid.importBackup(); else $('#qieRestoreInput').click();});
    window.QIERestore = text => {
      try {
        const backup=JSON.parse(text);
        if(backup.format!=='QIE-backup-v1'||!Array.isArray(backup.equipment)||backup.equipment.length>5000) throw new Error();
        if(backup.equipment.some(e=>!e||typeof e.id!=='string'||typeof e.tag!=='string'||!e.tag||!Array.isArray(e.points))) throw new Error();
        if(new Set(backup.equipment.map(e=>e.tag)).size!==backup.equipment.length) throw new Error();
        if(!confirm('Pulihkan data teknis dari backup? Database referensi PDF tetap digunakan.')) return;
        const previous=state.equipment;state.equipment=backup.equipment;
        if(save()) location.reload(); else state.equipment=previous;
      } catch(_) { toast('Backup tidak valid. Gunakan file backup Quick Identify Equipment.'); }
    };
    $('#qieRestoreInput').addEventListener('change', async e=>{const file=e.target.files[0];if(file){if(file.size>8*1024*1024){toast('Maksimum backup 8 MB.');return;}QIERestore(await file.text());}e.target.value='';});
    window.QIEBack = () => { const open=document.querySelector('dialog[open]');if(open){open.close();stopLiveQr();return true;} if($('#sidebar').classList.contains('open')){toggleMobileMenu(false);return true;} if(!$('#equipment').classList.contains('active')){goPage('equipment');return true;} return false; };
    $('#equipmentDialog').addEventListener('toggle', () => {
      const ref=initialState.equipment.some(e=>e.id===equipmentForm.elements.editId.value);
      ['tag','unitNumber','name','area','oil','grease','oilCapacity','greaseCapacity','greasePointDetails'].forEach(k=>{if(equipmentForm.elements[k])equipmentForm.elements[k].readOnly=ref;});
    });

    refreshAreaFilter(); refreshDatabaseAreaFilter(); renderAll();
    setLanguage(currentLanguage, false);
    openApplication();
  })();
  